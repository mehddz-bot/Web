import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

const DB_PATH = path.join(process.cwd(), "db.json");

// Helper to seed standard initial parts, mood, sensations, and journals 
// so the user has an insightful and populated dashboard immediately.
const getInitialData = () => {
  const now = new Date();
  
  // Helper to subtract days
  const subDays = (days: number) => {
    const d = new Date(now);
    d.setDate(now.getDate() - days);
    return d.toISOString();
  };

  return {
    parts: [
      {
        id: "p1",
        name: "The Perfectionist Critic",
        type: "manager",
        role: "Traces all actions to prevent making mistakes, ensuring we are always flawless so others won't reject us.",
        fear: "Fear of being seen as useless, incompetent, or completely abandoned by loved ones.",
        associatedSensations: ["tightness in chest", "jaw clenching"],
        color: "amber",
        createdAt: subDays(15)
      },
      {
        id: "p2",
        name: "The Achievement Driver",
        type: "manager",
        role: "Pushes relentlessly to work long hours, checklists, and maintain success metrics to feel valued.",
        fear: "Fear of sinking into deep depression or being forced to face the overwhelming isolation of the exile.",
        associatedSensations: ["shoulders tension", "heat in temples"],
        color: "blue",
        createdAt: subDays(14)
      },
      {
        id: "p3",
        name: "The Escape Compartment",
        type: "firefighter",
        role: "Switches our attention to social media, snacking, or absolute numbness when emotionally overwhelmed.",
        fear: "Fear that we will be completely incinerated or swallowed by the deep grief holding in the chest.",
        associatedSensations: ["hollowness in stomach", "numbness in limbs"],
        color: "rose",
        createdAt: subDays(12)
      },
      {
        id: "p4",
        name: "The Forgotten Child",
        type: "exile",
        role: "Holds the core memory of being unchosen and invisible in secondary school. Feels deeply broken and hollow.",
        fear: "Fear that its pain is permanent and that it is unlovable.",
        associatedSensations: ["recessed flutter in stomach", "cold throat lump"],
        color: "violet",
        createdAt: subDays(10)
      }
    ],
    somaticReadings: [
      {
        id: "s1",
        timestamp: subDays(8),
        location: "chest",
        x: 50,
        y: 45,
        type: "tightness",
        intensity: 7,
        associatedEmotion: "Fear",
        notes: "Tight pressure right behind the sternum, feels like an iron band. Linked to a sudden deadline.",
        partId: "p1"
      },
      {
        id: "s2",
        timestamp: subDays(6),
        location: "throat",
        x: 50,
        y: 28,
        type: "heaviness",
        intensity: 5,
        associatedEmotion: "Grief",
        notes: "Felt like a dense sphere holding in my throat, speaking was difficult. Puzzling about old friendships.",
        partId: "p4"
      },
      {
        id: "s3",
        timestamp: subDays(4),
        location: "shoulders",
        x: 35,
        y: 35,
        type: "heaviness",
        intensity: 6,
        associatedEmotion: "Anger",
        notes: "Massive block on shoulders, muscles burning like heated coal after reviewing the performance spreadsheet.",
        partId: "p2"
      },
      {
        id: "s4",
        timestamp: subDays(3),
        location: "stomach",
        x: 50,
        y: 58,
        type: "fluttering",
        intensity: 4,
        associatedEmotion: "Fear",
        notes: "Nervous butterflies before the presentation, pulsing flutter.",
        partId: "p1"
      },
      {
        id: "s5",
        timestamp: subDays(2),
        location: "jaw",
        x: 50,
        y: 19,
        type: "tightness",
        intensity: 8,
        associatedEmotion: "Anger",
        notes: "Clinched teeth. Hard to release even during meditation.",
        partId: "p1"
      },
      {
        id: "s6",
        timestamp: subDays(1),
        location: "stomach",
        x: 48,
        y: 57,
        type: "numbness",
        intensity: 5,
        associatedEmotion: "Shame",
        notes: "Cold, numb hollow feeling after a difficult boundary conversation.",
        partId: "p3"
      },
      {
        id: "s7",
        timestamp: now.toISOString(),
        location: "chest",
        x: 52,
        y: 44,
        type: "tingling",
        intensity: 3,
        associatedEmotion: "Peace",
        notes: "Checking in after standard grounding flow. Tightness has given way to warm, soft tingling expansion.",
        partId: "p4"
      }
    ],
    moodLogs: [
      { id: "m1", timestamp: subDays(6), value: 4, label: "Anxious", notes: "A lot of future-tripping and worrying about being perfect at my work." },
      { id: "m2", timestamp: subDays(5), value: 6, label: "Stressed", notes: "Busy day, protector part was driving me extremely hard." },
      { id: "m3", timestamp: subDays(4), value: 5, label: "Sad", notes: "Touched into some loneliness this afternoon, throat felt contracted." },
      { id: "m4", timestamp: subDays(3), value: 7, label: "Calm", notes: "Completed some box breathing and checked in with the perfectionist part." },
      { id: "m5", timestamp: subDays(2), value: 4, label: "Anxious", notes: "Hard evening, wanted to numb out with constant reading/scrolling." },
      { id: "m6", timestamp: subDays(1), value: 8, label: "Peaceful", notes: "Somatic therapy resourcing practice really settled my nervous system." },
      { id: "m7", timestamp: now.toISOString(), value: 9, label: "Calm", notes: "Feeling connected, spacious, and present, in true Self energy." }
    ],
    journals: [
      {
        id: "j1",
        timestamp: subDays(5),
        title: "Meeting the Critic",
        body: "I sat with the tight sensation in my chest today. When I asked it what it was doing, it showed me images of high-school spelling bees, desperately trying to get every letter correct. It represents 'The Perfectionist' manager. I thanked it for keeping me safe for so long. It felt a tiny bit softer afterwards.",
        moodValue: 5,
        associatedPartId: "p1"
      },
      {
        id: "j2",
        timestamp: subDays(1),
        title: "Numbing Out Patterns",
        body: "Recognized my Firefighter part (The Escape Compartment) trying to rescue me this evening. I was feeling an ambient anxiety in my stomach and immediately opened food delivery apps. Somatic tracking helped me locate the cold sensation in my stomach first. I paused and did 5 minutes of focused containment breathing.",
        moodValue: 8,
        associatedPartId: "p3"
      }
    ]
  };
};

// Ensure JSON database exists
const loadData = () => {
  try {
    if (!fs.existsSync(DB_PATH)) {
      const initial = getInitialData();
      fs.writeFileSync(DB_PATH, JSON.stringify(initial, null, 2));
      return initial;
    }
    const raw = fs.readFileSync(DB_PATH, "utf-8");
    return JSON.parse(raw);
  } catch (e) {
    console.error("Error reading database", e);
    return getInitialData();
  }
};

const saveData = (data: any) => {
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
  } catch (e) {
    console.error("Error saving database", e);
  }
};

// REST APIs
app.get("/api/data", (req, res) => {
  res.json(loadData());
});

// Parts
app.post("/api/parts", (req, res) => {
  const db = loadData();
  const newPart = req.body;
  if (!newPart.id) {
    newPart.id = "p_" + Date.now();
    newPart.createdAt = new Date().toISOString();
    db.parts.push(newPart);
  } else {
    const idx = db.parts.findIndex((p: any) => p.id === newPart.id);
    if (idx !== -1) {
      db.parts[idx] = { ...db.parts[idx], ...newPart };
    } else {
      db.parts.push(newPart);
    }
  }
  saveData(db);
  res.json({ success: true, part: newPart });
});

app.delete("/api/parts/:id", (req, res) => {
  const db = loadData();
  db.parts = db.parts.filter((p: any) => p.id !== req.params.id);
  // Also unassign from somatic readings
  db.somaticReadings = db.somaticReadings.map((s: any) => {
    if (s.partId === req.params.id) {
      const { partId, ...rest } = s;
      return rest;
    }
    return s;
  });
  saveData(db);
  res.json({ success: true });
});

// Somatic Readings
app.post("/api/somatic", (req, res) => {
  const db = loadData();
  const reading = req.body;
  if (!reading.id) {
    reading.id = "s_" + Date.now();
    reading.timestamp = new Date().toISOString();
    db.somaticReadings.push(reading);
  } else {
    const idx = db.somaticReadings.findIndex((r: any) => r.id === reading.id);
    if (idx !== -1) {
      db.somaticReadings[idx] = { ...db.somaticReadings[idx], ...reading };
    } else {
      db.somaticReadings.push(reading);
    }
  }
  saveData(db);
  res.json({ success: true, reading });
});

app.delete("/api/somatic/:id", (req, res) => {
  const db = loadData();
  db.somaticReadings = db.somaticReadings.filter((r: any) => r.id !== req.params.id);
  saveData(db);
  res.json({ success: true });
});

// Mood Logs
app.post("/api/mood", (req, res) => {
  const db = loadData();
  const log = req.body;
  log.id = "m_" + Date.now();
  log.timestamp = new Date().toISOString();
  db.moodLogs.push(log);
  saveData(db);
  res.json({ success: true, log });
});

// Journal
app.post("/api/journals", (req, res) => {
  const db = loadData();
  const journal = req.body;
  if (!journal.id) {
    journal.id = "j_" + Date.now();
    journal.timestamp = new Date().toISOString();
    db.journals.push(journal);
  } else {
    const idx = db.journals.findIndex((j: any) => j.id === journal.id);
    if (idx !== -1) {
      db.journals[idx] = { ...db.journals[idx], ...journal };
    } else {
      db.journals.push(journal);
    }
  }
  saveData(db);
  res.json({ success: true, journal });
});

app.delete("/api/journals/:id", (req, res) => {
  const db = loadData();
  db.journals = db.journals.filter((j: any) => j.id !== req.params.id);
  saveData(db);
  res.json({ success: true });
});

// Gemini Chat API - Somatic and IFS expert Practitioner dialogue
app.post("/api/chat", async (req, res) => {
  const { messages, contextInfo } = req.body;

  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.status(500).json({ 
        error: "GEMINI_API_KEY secret environment variable is missing on the server. Please define it in your AI Studio secrets settings." 
      });
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });

    // Provide a powerful, beautiful internal contextual instruction framing
    const contextPrompt = contextInfo 
      ? `\nCURRENT SESSION CONTEXT:\n${contextInfo}\n`
      : "";

    const systemInstruction = `You are a warm, highly-skilled Certified Somatic Psychotherapist and IFS (Internal Family Systems) Practitioner. 
Your goal is to guide the user in exploring their inner landscape with profound welcoming, compassion, curiosity, and presence (Self Leadership).

Use therapeutic principles of IFS and Somatic Experiencing:
1. **Body-First Inquiry (Somatic tracking)**: Encourage checking in with physical felt-senses (location, density, shape, color, motion, temperature). Avoid moving too fast into logical analysis.
2. **IFS Framework**: Treat sensations or defense responses as "Parts." Each part has an objective to protect, holds burden, and has positive intent, even if its role is destructive (like an inner critic or comforting firefighter).
3. **The 6 F's of Parts Work**:
   - **Find**: Locate the part in or around the body (sensation).
   - **Focus**: Turn awareness toward it with quiet curiosity.
   - **Flesh it out**: Describe it (its appearance, shape, texture, feel, distance).
   - **Feel towards**: Ask the user: "How do you feel towards this part?" (If there is fear, anger, resentment, or frustration, gently guide them to ask those critical/reactive parts to step back so curiosity/Self energy can lead).
   - **Befriend**: Ask the part about its job, fear, what it protects, and what it needs.
   - **Fear**: Find what it is afraid would happen if it stopped doing its job.
4. **Resourcing**: If the user feels overwhelmed (flooded, hyper-aroused, dissociating), guide them back to grounding: feeling their feet on the floor, holding safe self-touch (heart and stomach), looking around the room, or soft box breathing. No active parts-work should occur if the client feels unsafe.

CRITICAL RULES:
- Keep responses relatively brief (150-250 words) to mimic a real conversational session. No lengthy text dumps.
- Speak in the second person ("you", "your").
- Maintain a calm, spacious, unhurried, gentle tone. No hype or clinical jargon.
- Introduce 1 or at most 2 gentle, curious inquiry questions per turn so the user can actually digest, breathe, and feel.
- Format responses cleanly with brief markdown paragraphs and maybe a bulleted, gentle physical exercise or question if relevant. Do not output massive lists or overly structured tables.
${contextPrompt}`;

    const contents = messages.map((m: any) => ({
      role: m.role,
      parts: [{ text: m.text }]
    }));

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents,
      config: {
        systemInstruction,
        temperature: 0.7,
      }
    });

    const replyText = response.text || "I was unable to retrieve a response from the wisdom space. Let's take a deep breath and try checking in again.";
    
    res.json({ 
      id: "resp_" + Date.now(),
      role: 'model',
      text: replyText,
      timestamp: new Date().toISOString()
    });

  } catch (error: any) {
    console.error("Gemini API error in server:", error);
    res.status(500).json({ 
      error: "Somatic AI Assistant encountered an error. Please try again. Detailed information: " + (error?.message || error)
    });
  }
});

// Setup Vite Dev server or production build static folder serving
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`IFS and Somatic Healing Server listening on port ${PORT}`);
  });
}

startServer();
