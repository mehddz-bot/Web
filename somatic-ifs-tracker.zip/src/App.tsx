import React, { useState, useEffect } from 'react';
import { SomaticReading, MoodLog, IFSPart, JournalEntry } from './types';
import SomaticDashboard from './components/SomaticDashboard';
import PartsManager from './components/PartsManager';
import SomaticJournal from './components/SomaticJournal';
import TherapeuticChat from './components/TherapeuticChat';
import GuidedSessionPlayer from './components/GuidedSessionPlayer';
import SomaticCharts from './components/SomaticCharts';
import {
  Heart,
  Compass,
  BookOpen,
  MessageSquare,
  BarChart3,
  Sparkles,
  Activity,
  ShieldAlert,
  HelpCircle
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'parts' | 'journal' | 'assistant' | 'exercises' | 'charts'>('dashboard');
  
  // Data states
  const [readings, setReadings] = useState<SomaticReading[]>([]);
  const [moodLogs, setMoodLogs] = useState<MoodLog[]>([]);
  const [parts, setParts] = useState<IFSPart[]>([]);
  const [journals, setJournals] = useState<JournalEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [errorStatus, setErrorStatus] = useState<string | null>(null);

  // Sync with Express database
  const fetchData = async () => {
    try {
      const res = await fetch('/api/data');
      if (!res.ok) throw new Error("Could not load stored session databases.");
      const data = await res.json();
      setReadings(data.somaticReadings || []);
      setMoodLogs(data.moodLogs || []);
      setParts(data.parts || []);
      setJournals(data.journals || []);
    } catch (e: any) {
      console.error(e);
      setErrorStatus(e?.message || e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Somatic Readings API Handlers
  const handleAddReading = async (newReading: Omit<SomaticReading, 'id' | 'timestamp'>) => {
    try {
      const res = await fetch('/api/somatic', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newReading)
      });
      if (!res.ok) throw new Error("Failed to persist somatic check-in.");
      const result = await res.json();
      // Reload from DB to keep robust sync
      fetchData();
    } catch (e: any) {
      alert(e?.message || e);
    }
  };

  const handleDeleteReading = async (id: string) => {
    try {
      const res = await fetch(`/api/somatic/${id}`, { method: 'DELETE' });
      if (!res.ok) throw new Error("Failed to remove somatic pin.");
      fetchData();
    } catch (e: any) {
      alert(e?.message || e);
    }
  };

  // IFS Parts Handlers
  const handleAddPart = async (newPart: Omit<IFSPart, 'id' | 'createdAt'>) => {
    try {
      const res = await fetch('/api/parts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newPart)
      });
      if (!res.ok) throw new Error("Failed to save protective part.");
      fetchData();
    } catch (e: any) {
      alert(e?.message || e);
    }
  };

  const handleDeletePart = async (id: string) => {
    try {
      const res = await fetch(`/api/parts/${id}`, { method: 'DELETE' });
      if (!res.ok) throw new Error("Could not archive chosen part.");
      fetchData();
    } catch (e: any) {
      alert(e?.message || e);
    }
  };

  // Mood Logs Handler
  const handleAddMoodLog = async (newMood: Omit<MoodLog, 'id' | 'timestamp'>) => {
    try {
      const res = await fetch('/api/mood', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newMood)
      });
      if (!res.ok) throw new Error("Failed to save daily check-in.");
      fetchData();
    } catch (e: any) {
      alert(e?.message || e);
    }
  };

  // Journals Handlers
  const handleAddJournal = async (newJournal: Omit<JournalEntry, 'id' | 'timestamp'>) => {
    try {
      const res = await fetch('/api/journals', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newJournal)
      });
      if (!res.ok) throw new Error("Failed to record journal narrative.");
      fetchData();
    } catch (e: any) {
      alert(e?.message || e);
    }
  };

  const handleDeleteJournal = async (id: string) => {
    try {
      const res = await fetch(`/api/journals/${id}`, { method: 'DELETE' });
      if (!res.ok) throw new Error("Could not erase specified journal.");
      fetchData();
    } catch (e: any) {
      alert(e?.message || e);
    }
  };

  const getActiveTabComponent = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <SomaticDashboard
            readings={readings}
            moodLogs={moodLogs}
            parts={parts}
            onAddReading={handleAddReading}
            onDeleteReading={handleDeleteReading}
            onAddMoodLog={handleAddMoodLog}
          />
        );
      case 'parts':
        return (
          <PartsManager
            parts={parts}
            onAddPart={handleAddPart}
            onDeletePart={handleDeletePart}
          />
        );
      case 'journal':
        return (
          <SomaticJournal
            journals={journals}
            parts={parts}
            readings={readings}
            onAddJournal={handleAddJournal}
            onDeleteJournal={handleDeleteJournal}
          />
        );
      case 'assistant':
        return <TherapeuticChat parts={parts} readings={readings} />;
      case 'exercises':
        return <GuidedSessionPlayer />;
      case 'charts':
        return <SomaticCharts readings={readings} moodLogs={moodLogs} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0C10] text-slate-200 flex flex-col font-sans selection:bg-indigo-500/30 selection:text-white">
      
      {/* Top Navigation bar */}
      <header className="border-b border-slate-800/50 bg-slate-900/20 sticky top-0 z-50 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 bg-gradient-to-tr from-indigo-500 to-teal-400 rounded-full flex items-center justify-center shadow-[0_0_15px_rgba(79,70,229,0.4)]">
              <Compass className="h-5 w-5 text-white animate-spin-slow" />
            </div>
            <div className="flex flex-col">
              <span className="font-display font-medium text-lg leading-tight tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white to-slate-400">
                Somatic IFS Space
              </span>
              <span className="text-[9px] font-mono tracking-[0.2em] text-slate-500 uppercase">
                INTEGRATED HEALING ALIGNMENT
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1.5 bg-slate-900/40 border border-slate-800/50 rounded-full px-3.5 py-1 text-[10px] font-mono text-slate-400">
            <Activity className="h-3.5 w-3.5 text-teal-400" />
            <span>Nervous System: Coherent</span>
          </div>
          
        </div>
      </header>

      {/* Main Container workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col gap-8">
        
        {/* Banner Welcome Message */}
        <div className="bg-slate-900/40 rounded-3xl border border-slate-800/50 p-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 relative overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_40%,rgba(45,212,191,0.05)_0%,transparent_60%)] pointer-events-none"></div>
          
          <div className="relative z-10">
            <span className="text-[10px] font-semibold text-slate-500 uppercase tracking-[0.2em]">WELCOME TO PRESENCE</span>
            <h1 className="font-display font-medium text-2xl text-slate-100 leading-tight mt-1">
              Honor your body, connect with your parts.
            </h1>
            <p className="text-xs text-slate-400 mt-2 font-sans max-w-xl leading-relaxed">
              Use this digital refuge to track raw somatic sensations on the clickable human map, catalogue your Internal Family Systems protectors, write journals, and practice calming respiratory exercises.
            </p>
          </div>

          <div className="relative z-10 flex items-center gap-1.5 text-xs text-teal-300 font-sans border border-teal-500/30 bg-teal-500/10 rounded-full px-4 py-2 shadow-[0_0_12px_rgba(20,184,166,0.15)]">
            <Sparkles className="h-4 w-4 text-teal-400 animate-pulse" />
            <span>Grounded Self energy leads the system.</span>
          </div>
        </div>

        {/* Global Error Banner */}
        {errorStatus && (
          <div className="bg-rose-950/30 border border-rose-900/40 p-4 rounded-xl flex items-start gap-3">
            <ShieldAlert className="h-5 w-5 text-rose-400 shrink-0 mt-0.5" />
            <div className="flex-1">
              <h5 className="font-sans font-semibold text-rose-300 text-sm">System Interruption</h5>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Could not establish secure data persistence with the Express database: {errorStatus}. Running with fallback memory.
              </p>
            </div>
          </div>
        )}

        {/* Tab Triggers panel */}
        <div className="flex border-b border-slate-800/50 overflow-x-auto gap-2 sm:gap-4 pb-px no-scrollbar">
          {[
            { id: 'dashboard', label: 'Somatic Canvas', icon: <Compass className="h-4 w-4" /> },
            { id: 'parts', label: 'IFS Sub-Selves', icon: <Heart className="h-4 w-4" /> },
            { id: 'journal', label: 'Somatic Narrative', icon: <BookOpen className="h-4 w-4" /> },
            { id: 'assistant', label: 'AI Clinician Guide', icon: <MessageSquare className="h-4 w-4" /> },
            { id: 'exercises', label: 'Sensory Practices', icon: <Activity className="h-4 w-4" /> },
            { id: 'charts', label: 'Body Metrics', icon: <BarChart3 className="h-4 w-4" /> }
          ].map((tab) => {
            const isSelected = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                id={`tab-trigger-${tab.id}`}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-3 px-3.5 text-xs font-sans font-semibold border-b-2 flex items-center gap-2 transition-all duration-300 pointer-events-auto whitespace-nowrap cursor-pointer ${
                  isSelected
                    ? 'border-teal-400 text-teal-400 bg-teal-400/5'
                    : 'border-transparent text-slate-400 hover:text-white hover:border-slate-800'
                }`}
              >
                {tab.icon}
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Loading Indicator */}
        {loading ? (
          <div className="flex-grow flex items-center justify-center py-20">
            <div className="flex flex-col items-center gap-3">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-indigo-500"></span>
              </span>
              <p className="text-xs text-slate-500 font-mono tracking-widest uppercase">Connecting with central memory psyche...</p>
            </div>
          </div>
        ) : (
          /* Render Active Panel Frame */
          <div className="flex-1 animate-fade-in">
            {getActiveTabComponent()}
          </div>
        )}

      </main>

      {/* Spacious Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/40 py-8 mt-auto text-slate-500 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-4">
          
          <div className="flex items-center gap-2">
            <Heart className="h-4 w-4 text-indigo-500/60" />
            <p className="font-sans">
              Developed securely under the principles of self-governing somatic protection. All data is saved local to your container.
            </p>
          </div>

          <div className="flex items-center gap-4 text-[10px] font-mono">
            <span className="border border-slate-800/80 rounded px-2 py-0.5">Somatic Experiencing © 2026</span>
            <span className="border border-slate-800/80 rounded px-2 py-0.5">IFS Institute compliant</span>
          </div>

        </div>
      </footer>

    </div>
  );
}
