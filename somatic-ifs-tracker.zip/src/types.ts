export type PartType = 'manager' | 'firefighter' | 'exile';

export interface IFSPart {
  id: string;
  name: string;
  type: PartType;
  role: string;
  fear: string; // What the part is afraid would happen if it stopped its role
  associatedSensations: string[]; // e.g. ["tightness in chest", "lump in throat"]
  color: string; // Hex or tailwind class
  createdAt: string;
}

export interface SomaticReading {
  id: string;
  timestamp: string;
  location: string; // "head" | "jaw" | "throat" | "chest" | "shoulders" | "stomach" | "back" | "limbs" | "pelvis"
  x: number; // percentage coordinate on body chart
  y: number; // percentage coordinate on body chart
  type: 'tightness' | 'tingling' | 'heaviness' | 'heat' | 'cold' | 'numbness' | 'fluttering' | 'sharp' | 'dull' | 'pulsing';
  intensity: number; // 1-10
  associatedEmotion: string; // "Fear", "Anger", "Grief", "Shame", "Guilt", "Joy", "Peace", "Excitement"
  notes?: string;
  partId?: string; // Associated IFS Part
}

export interface MoodLog {
  id: string;
  timestamp: string;
  value: number; // 1-10
  label: string; // "Calm", "Anxious", "Stressed", "Angry", "Sad", "Peaceful", "Numb"
  notes?: string;
}

export interface JournalEntry {
  id: string;
  timestamp: string;
  title: string;
  body: string;
  moodValue?: number;
  associatedPartId?: string;
  associatedSensationId?: string; 
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
}

export interface GuidedSession {
  id: string;
  title: string;
  description: string;
  durationSeconds: number;
  category: 'grounding' | 'parts-dialogue' | 'somatics' | 'resourcing';
  steps: string[];
}
