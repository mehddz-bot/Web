import React, { useRef, useState } from 'react';
import { SomaticReading } from '../types';
import { Shield, Sparkles, AlertCircle } from 'lucide-react';

interface BodyMapProps {
  readings: SomaticReading[];
  onSelectReading?: (reading: SomaticReading) => void;
  onMapClick?: (coords: { x: number; y: number; location: string }) => void;
  selectedReadingId?: string | null;
  interactive?: boolean;
}

// Maps standard SVG sections to location labels
const getBodyLocationFromCoords = (y: number, x: number): string => {
  if (y < 20) return 'head';
  if (y >= 20 && y < 25 && x >= 45 && x <= 55) return 'jaw';
  if (y >= 25 && y < 30) return 'throat';
  if (y >= 30 && y < 45) {
    if (x >= 40 && x <= 60) return 'chest';
    return 'shoulders';
  }
  if (y >= 45 && y < 65) return 'stomach';
  if (y >= 65 && y < 75) return 'pelvis';
  if (x < 35 || x > 65) return 'limbs';
  return 'back';
};

export default function BodyMap({
  readings,
  onSelectReading,
  onMapClick,
  selectedReadingId,
  interactive = true,
}: BodyMapProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [hoveredLocation, setHoveredLocation] = useState<string | null>(null);

  const handleSVGClick = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!interactive || !onMapClick || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = Math.round(((e.clientX - rect.left) / rect.width) * 100);
    const y = Math.round(((e.clientY - rect.top) / rect.height) * 100);
    const location = getBodyLocationFromCoords(y, x);
    onMapClick({ x, y, location });
  };

  const handleSVGMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = Math.round(((e.clientX - rect.left) / rect.width) * 100);
    const y = Math.round(((e.clientY - rect.top) / rect.height) * 100);
    setHoveredLocation(getBodyLocationFromCoords(y, x));
  };

  // Helper for emotion color theme
  const getEmotionColor = (emotion: string) => {
    switch (emotion?.toLowerCase()) {
      case 'fear':
        return '#f59e0b'; // amber
      case 'anger':
        return '#ef4444'; // red
      case 'grief':
        return '#3b82f6'; // blue
      case 'shame':
        return '#8b5cf6'; // violet
      case 'guilt':
        return '#6366f1'; // indigo
      case 'joy':
        return '#10b981'; // emerald
      case 'peace':
        return '#14b8a6'; // teal
      default:
        return '#6b7280'; // gray
    }
  };

  return (
    <div className="relative flex flex-col items-center bg-slate-900/40 p-6 rounded-2xl border border-slate-800 backdrop-blur-md shadow-inner h-full">
      <div className="absolute top-4 left-4 flex flex-col gap-1.5 pointer-events-none">
        <span className="text-xs font-mono text-slate-400">ANATOMICAL MAP</span>
        <div className="flex items-center gap-1.5 text-xs text-rose-400">
          <span className="h-2 w-2 rounded-full bg-rose-500 animate-pulse"></span>
          <span className="capitalize font-medium text-slate-300">
            {hoveredLocation ? `${hoveredLocation} region` : 'Body scanning active'}
          </span>
        </div>
      </div>

      <div className="absolute top-4 right-4 text-right pointer-events-none">
        <span className="text-xs font-mono text-indigo-400">PERSISTENCE SCALE</span>
      </div>

      {/* Map body container */}
      <div 
        ref={containerRef} 
        id="body-canvas-container"
        className="relative w-72 h-[420px] my-6 transition-all duration-300"
      >
        <svg
          viewBox="0 0 100 100"
          className={`w-full h-full select-none ${interactive ? 'cursor-crosshair' : ''}`}
          onClick={handleSVGClick}
          onMouseMove={handleSVGMouseMove}
          onMouseLeave={() => setHoveredLocation(null)}
        >
          {/* Subtle Grid lines */}
          <line x1="10" y1="20" x2="90" y2="20" stroke="#1e293b" strokeWidth="0.15" strokeDasharray="1,2" />
          <line x1="10" y1="40" x2="90" y2="40" stroke="#1e293b" strokeWidth="0.15" strokeDasharray="1,2" />
          <line x1="10" y1="60" x2="90" y2="60" stroke="#1e293b" strokeWidth="0.15" strokeDasharray="1,2" />
          <line x1="50" y1="5" x2="50" y2="95" stroke="#1e293b" strokeWidth="0.15" strokeDasharray="1,2" />

          {/* Elegant Minimal Human Figure Path */}
          <g className="fill-slate-800/40 stroke-slate-700/60" strokeWidth="0.8">
            {/* Head */}
            <path d="M 50 6 C 53.5 6, 56 8, 56 12 C 56 15.5, 53.5 17.5, 50 17.5 C 46.5 17.5, 44 15.5, 44 12 C 44 8, 46.5 6, 50 6" />
            
            {/* Jaw/Neck */}
            <path d="M 47.5 17 Q 50 19, 52.5 17 L 52 23.5 L 48 23.5 Z" />
            
            {/* Shoulders / Torso / Pelvis */}
            <path d="M 48 23 L 34 26 C 30 27, 30.5 30, 31.5 31.5 L 36.5 36.5 L 38 43 L 36.5 54 L 38 65 Q 40 68, 43 68 L 57 68 Q 60 68, 62 65 L 63.5 54 L 62 43 L 63.5 36.5 L 68.5 31.5 C 69.5 30, 70 27, 66 26 L 52 23" />
            
            {/* Right Arm */}
            <path d="M 31.5 31.5 L 23 44 C 21.5 46.5, 23.5 50, 26 48 L 36.5 36.5" />
            
            {/* Left Arm */}
            <path d="M 68.5 31.5 L 77 44 C 78.5 46.5, 76.5 50, 74 48 L 63.5 36.5" />
            
            {/* Right Leg */}
            <path d="M 43 68 L 40 82 L 41.5 94 C 41.5 96.5, 38.5 96.5, 38.5 94 L 37.5 82 L 41 68" />
            
            {/* Left Leg */}
            <path d="M 57 68 L 60 82 L 58.5 94 C 58.5 96.5, 61.5 96.5, 61.5 94 L 62.5 82 L 59 68" />
          </g>

          {/* Active Hover anatomy highlighting overlays */}
          {hoveredLocation === 'head' && (
            <ellipse cx="50" cy="11.5" rx="5" ry="5.5" fill="#f43f5e" fillOpacity="0.12" className="pointer-events-none" />
          )}
          {hoveredLocation === 'throat' && (
            <path d="M 47.5 22 Q 50 25, 52.5 22 M 48 24 L 52 24 L 51 28 L 49 28 Z" fill="#f43f5e" fillOpacity="0.15" className="pointer-events-none" />
          )}
          {hoveredLocation === 'chest' && (
            <ellipse cx="50" cy="37" rx="9" ry="7" fill="#f43f5e" fillOpacity="0.12" className="pointer-events-none" />
          )}
          {hoveredLocation === 'shoulders' && (
            <path d="M 33 26.5 C 31 27, 31 29, 32 30 L 37 36 L 40 33 Z M 67 26.5 C 69 27, 69 29, 68 30 L 63 36 L 60 33 Z" fill="#f43f5e" fillOpacity="0.15" className="pointer-events-none" />
          )}
          {hoveredLocation === 'stomach' && (
            <ellipse cx="50" cy="53" rx="10" ry="9" fill="#f43f5e" fillOpacity="0.12" className="pointer-events-none" />
          )}
          {hoveredLocation === 'jaw' && (
            <ellipse cx="50" cy="16.5" rx="3.5" ry="2" fill="#f43f5e" fillOpacity="0.18" className="pointer-events-none" />
          )}

          {/* Draw pins of historic somatic readings */}
          {readings.map((reading) => {
            const isSelected = reading.id === selectedReadingId;
            const size = 3 + (reading.intensity * 0.4); // scale to intensity
            const color = getEmotionColor(reading.associatedEmotion);

            return (
              <g 
                key={reading.id} 
                className="cursor-pointer transition-all duration-300 group"
                onClick={(e) => {
                  e.stopPropagation();
                  if (onSelectReading) onSelectReading(reading);
                }}
              >
                {/* Outward pulsing ring */}
                <circle
                  cx={reading.x}
                  cy={reading.y}
                  r={size * 1.8}
                  fill={color}
                  fillOpacity="0.15"
                  className={isSelected ? 'animate-ping origin-center' : 'group-hover:scale-125 transition-transform duration-300'}
                  style={{ transformOrigin: `${reading.x}% ${reading.y}%` }}
                />

                {/* Base circle glow */}
                <circle
                  cx={reading.x}
                  cy={reading.y}
                  r={size}
                  fill={color}
                  fillOpacity={isSelected ? "0.8" : "0.5"}
                  stroke={isSelected ? "#ffffff" : color}
                  strokeWidth={isSelected ? "1" : "0.4"}
                />

                {/* Core focal element */}
                <circle
                  cx={reading.x}
                  cy={reading.y}
                  r="1.2"
                  fill="#ffffff"
                />
              </g>
            );
          })}
        </svg>

        {/* Dynamic Instructional Overlay when empty */}
        {interactive && readings.length === 0 && (
          <div className="absolute inset-0 flex items-center justify-center p-4 bg-slate-950/60 rounded-xl border border-slate-800/80 backdrop-blur-sm pointer-events-none">
            <div className="text-center flex flex-col items-center gap-2 max-w-[200px]">
              <Sparkles className="h-5 w-5 text-indigo-400 animate-pulse" />
              <p className="text-xs text-slate-300 leading-relaxed font-sans">
                No somatic points logged today. Click anywhere on the silhouette to track a physical sensation.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Legend Map */}
      <div className="w-full border-t border-slate-800/80 pt-4 mt-auto">
        <h4 className="text-[10px] font-mono tracking-wider text-slate-500 mb-2 uppercase">EMOTIONAL ASSIGNMENT COLOR CODE</h4>
        <div className="grid grid-cols-4 gap-y-1.5 gap-x-2 text-[10px]">
          <div className="flex items-center gap-1.5 text-slate-300 font-sans">
            <span className="h-2 w-2 rounded-full bg-amber-500"></span>
            <span>Fear</span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-300 font-sans">
            <span className="h-2 w-2 rounded-full bg-red-500"></span>
            <span>Anger</span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-300 font-sans">
            <span className="h-2 w-2 rounded-full bg-blue-500"></span>
            <span>Grief</span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-300 font-sans">
            <span className="h-2 w-2 rounded-full bg-violet-500"></span>
            <span>Shame</span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-300 font-sans">
            <span className="h-2 w-2 rounded-full bg-emerald-500"></span>
            <span>Joy</span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-300 font-sans">
            <span className="h-2 w-2 rounded-full bg-teal-500"></span>
            <span>Peace</span>
          </div>
        </div>
      </div>
    </div>
  );
}
