import React, { useState } from 'react';
import { SomaticReading, MoodLog, IFSPart } from '../types';
import BodyMap from './BodyMap';
import { Shield, Sparkles, AlertCircle, Trash2, Heart, Smile } from 'lucide-react';

interface SomaticDashboardProps {
  readings: SomaticReading[];
  moodLogs: MoodLog[];
  parts: IFSPart[];
  onAddReading: (reading: Omit<SomaticReading, 'id' | 'timestamp'>) => void;
  onDeleteReading: (id: string) => void;
  onAddMoodLog: (moodLog: Omit<MoodLog, 'id' | 'timestamp'>) => void;
}

export default function SomaticDashboard({
  readings,
  moodLogs,
  parts,
  onAddReading,
  onDeleteReading,
  onAddMoodLog,
}: SomaticDashboardProps) {
  // Coordinate selector from click on BodyMap
  const [coords, setCoords] = useState<{ x: number; y: number; location: string } | null>(null);
  const [selectedReading, setSelectedReading] = useState<SomaticReading | null>(null);

  // Form states for somatic reading
  const [type, setType] = useState<SomaticReading['type']>('tightness');
  const [intensity, setIntensity] = useState(5);
  const [associatedEmotion, setAssociatedEmotion] = useState('Fear');
  const [notes, setNotes] = useState('');
  const [partId, setPartId] = useState('');
  
  // Mood Log state
  const [moodValue, setMoodValue] = useState(7);
  const [moodLabel, setMoodLabel] = useState('Calm');
  const [moodNotes, setMoodNotes] = useState('');
  const [moodLoggedToday, setMoodLoggedToday] = useState(false);

  const handleMapClick = (clickCoords: { x: number; y: number; location: string }) => {
    setCoords(clickCoords);
    setSelectedReading(null); // Clear detailed inspector
  };

  const handleSelectReading = (reading: SomaticReading) => {
    setSelectedReading(reading);
    setCoords(null); // Close creation form
  };

  const submitReading = (e: React.FormEvent) => {
    e.preventDefault();
    if (!coords) return;

    onAddReading({
      location: coords.location,
      x: coords.x,
      y: coords.y,
      type,
      intensity,
      associatedEmotion,
      notes: notes.trim() || undefined,
      partId: partId || undefined
    });

    // Reset Form
    setCoords(null);
    setNotes('');
    setPartId('');
    setIntensity(5);
  };

  const submitMoodLog = (e: React.FormEvent) => {
    e.preventDefault();
    onAddMoodLog({
      value: moodValue,
      label: moodLabel,
      notes: moodNotes.trim() || undefined
    });
    setMoodNotes('');
    setMoodLoggedToday(true);
  };

  // Streak calculations
  const calculateStreak = () => {
    if (moodLogs.length === 0) return 0;
    return moodLogs.length; // Simplified streak representing logged updates in history
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
      
      {/* Left Column: Body Map and active check-in form */}
      <div className="xl:col-span-2 flex flex-col gap-6">
        
        <div className="bg-slate-900/40 border border-slate-800/50 rounded-3xl p-6 backdrop-blur-md relative overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_30%,rgba(99,102,241,0.03)_0%,transparent_60%)] pointer-events-none"></div>
          <div className="flex flex-col md:flex-row gap-6 relative z-10">
            
            {/* SVG Interactive Canvas */}
            <div className="w-full md:w-80 shrink-0">
              <BodyMap
                readings={readings}
                onSelectReading={handleSelectReading}
                onMapClick={handleMapClick}
                selectedReadingId={selectedReading ? selectedReading.id : null}
                interactive={true}
              />
            </div>

            {/* Dynamic Interactive side-panel */}
            <div className="flex-1 flex flex-col justify-between">
              
              {/* Scenario 1: No point selected and no click coords (Inquiry Mode) */}
              {!coords && !selectedReading && (
                <div className="flex-1 flex flex-col justify-center gap-4 py-8">
                  <div className="flex items-center gap-2 text-indigo-400">
                    <Sparkles className="h-5 w-5 animate-pulse" />
                    <h4 className="text-xs font-semibold uppercase tracking-[0.2em] text-slate-300">Live Body-Sensing Canvas</h4>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed font-sans mt-1">
                    Tap anywhere on the anatomical template to map a physical sensation.
                  </p>
                  <p className="text-[11px] text-slate-400 leading-relaxed font-sans mt-2 bg-black/20 p-4 rounded-2xl border border-slate-800/30">
                    Somatic Experiencing teaches that emotions are not just concepts – they are real biological patterns. Tightness in the throat may represent unspoken boundaries (fear/grief); butterflies in the stomach can highlight safety seeking. Mapping these sensations opens up dialogue.
                  </p>
                </div>
              )}

              {/* Scenario 2: Placing a new check-in pin point */}
              {coords && (
                <form onSubmit={submitReading} className="flex-1 flex flex-col gap-3.5">
                  <div className="flex items-center justify-between border-b border-slate-800/50 pb-2.5">
                    <div className="flex items-center gap-1.5 text-indigo-400">
                      <Sparkles className="h-4 w-4 animate-spin-slow" />
                      <span className="text-xs font-semibold uppercase tracking-[0.15em] text-slate-200">
                        {coords.location} region
                      </span>
                    </div>
                    <span className="text-[10px] font-mono text-slate-500">
                      Coordinates: {coords.x}x, {coords.y}y
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="flex flex-col gap-1">
                      <label className="text-[9px] font-mono tracking-wider text-slate-500">SENSATION TYPE</label>
                      <select
                        value={type}
                        id="form-sensation-type"
                        onChange={(e) => setType(e.target.value as any)}
                        className="bg-slate-950/80 border border-slate-800/60 text-slate-300 text-xs rounded-xl p-2 focus:outline-none focus:border-indigo-500 transition-colors"
                      >
                        <option value="tightness">Tightness</option>
                        <option value="tingling">Tingling Warmth</option>
                        <option value="heaviness">Heaviness</option>
                        <option value="heat">Heat</option>
                        <option value="cold">Cold Empty</option>
                        <option value="numbness">Numbness</option>
                        <option value="fluttering">Fluttering</option>
                        <option value="sharp">Sharp Pinch</option>
                        <option value="dull">Dull Ache</option>
                        <option value="pulsing">Pulsing Beats</option>
                      </select>
                    </div>

                    <div className="flex flex-col gap-1">
                      <label className="text-[9px] font-mono tracking-wider text-slate-500">ASSOCIATED EMOTION</label>
                      <select
                        value={associatedEmotion}
                        id="form-sensation-emotion"
                        onChange={(e) => setAssociatedEmotion(e.target.value)}
                        className="bg-slate-950/80 border border-slate-800/60 text-slate-300 text-xs rounded-xl p-2 focus:outline-none focus:border-indigo-500 transition-colors"
                      >
                        <option value="Fear">Fear</option>
                        <option value="Anger">Anger</option>
                        <option value="Grief">Grief</option>
                        <option value="Shame">Shame</option>
                        <option value="Guilt">Guilt</option>
                        <option value="Joy">Joy</option>
                        <option value="Peace">Peace & Release</option>
                      </select>
                    </div>
                  </div>

                  <div className="flex flex-col gap-1">
                    <div className="flex justify-between text-[9px] font-mono tracking-wider text-slate-500">
                      <span>INTENSITY SCALE</span>
                      <span className="text-rose-400 font-bold">{intensity}/10</span>
                    </div>
                    <input
                      type="range"
                      min="1"
                      max="10"
                      value={intensity}
                      id="form-sensation-intensity"
                      onChange={(e) => setIntensity(Number(e.target.value))}
                      className="w-full accent-indigo-500 bg-slate-800 h-1.5 rounded cursor-pointer mt-1"
                    />
                  </div>

                  <div className="flex flex-col gap-1">
                    <label className="text-[9px] font-mono tracking-wider text-slate-500">CONNECTED IFS PROTECTION PART (OPTIONAL)</label>
                    <select
                      value={partId}
                      id="form-sensation-part"
                      onChange={(e) => setPartId(e.target.value)}
                      className="bg-slate-950/80 border border-slate-800/60 text-slate-300 text-xs rounded-xl p-2 focus:outline-none focus:border-indigo-500 transition-colors"
                    >
                      <option value="">No registered protective part</option>
                      {parts.map(p => (
                        <option key={p.id} value={p.id}>{p.name} ({p.type})</option>
                      ))}
                    </select>
                  </div>

                  <div className="flex flex-col gap-1">
                    <label className="text-[9px] font-mono tracking-wider text-slate-500">QUALITATIVE NOTES / FEEL DETAIL</label>
                    <input
                      type="text"
                      value={notes}
                      id="form-sensation-notes"
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="e.g. pressure expands on exhale, frozen block"
                      className="bg-slate-950/80 border border-slate-800/60 text-slate-300 text-xs rounded-xl p-2 focus:outline-none focus:border-indigo-500 transition-colors"
                    />
                  </div>

                  <div className="flex gap-2.5 mt-2">
                    <button
                      type="submit"
                      id="form-somatic-commit-btn"
                      className="flex-1 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold py-2.5 px-4 rounded-xl transition-all cursor-pointer shadow-[0_0_15px_rgba(79,70,229,0.3)] hover:shadow-[0_0_20px_rgba(79,70,229,0.5)]"
                    >
                      Add Sensation Pin
                    </button>
                    <button
                      type="button"
                      id="form-somatic-cancel-btn"
                      onClick={() => setCoords(null)}
                      className="bg-slate-950/80 border border-slate-800 text-slate-400 text-xs px-4 rounded-xl hover:bg-slate-900 transition-all cursor-pointer"
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              )}

              {/* Scenario 3: Inspection of an existing point pin */}
              {selectedReading && (
                <div className="flex-1 flex flex-col justify-between gap-4">
                  <div className="flex flex-col gap-2 bg-black/20 p-5 border border-slate-800/50 rounded-2xl relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-1 h-full bg-indigo-500"></div>
                    
                    <div className="flex items-center justify-between text-[9px] font-mono tracking-wider text-slate-400">
                      <span className="uppercase tracking-[0.1em]">HISTORIC SENSE PIN</span>
                      <span>{new Date(selectedReading.timestamp).toLocaleDateString()}</span>
                    </div>

                    <h4 className="font-sans font-semibold text-slate-100 capitalize text-sm mt-1.5 flex items-center gap-1.5">
                      {selectedReading.type} in {selectedReading.location}
                      <span className="text-xs bg-rose-950/80 text-rose-300 border border-rose-900/40 px-2.5 py-0.5 rounded-full ml-auto font-mono">
                        Lvl {selectedReading.intensity}/10
                      </span>
                    </h4>

                    {selectedReading.partId && (
                      <div className="flex items-center gap-1.5 text-xs text-indigo-300 font-sans mt-2 bg-indigo-500/10 px-3 py-1 rounded-xl border border-indigo-500/20 w-fit">
                        <Shield className="h-3.5 w-3.5" />
                        <span>Connected Part: {parts.find(p => p.id === selectedReading.partId)?.name || 'Aspect'}</span>
                      </div>
                    )}

                    <div className="text-xs text-slate-300 mt-2.5 font-sans leading-relaxed flex flex-col gap-1.5">
                      <span className="font-mono text-[9px] text-slate-500 uppercase">EMOTIONAL ASSIGNMENT: {selectedReading.associatedEmotion}</span>
                      <p className="italic bg-black/10 p-3 border border-slate-800/40 rounded-xl font-light">{selectedReading.notes || 'No description logged.'}</p>
                    </div>
                  </div>

                  <div className="flex gap-2.5 mt-2">
                    <button
                      onClick={() => {
                        onDeleteReading(selectedReading.id);
                        setSelectedReading(null);
                      }}
                      id="btn-remove-reading-pin"
                      className="flex-1 bg-slate-900 border border-slate-800/60 hover:bg-rose-950/30 hover:border-rose-900 text-rose-300 text-xs font-semibold py-2.5 px-3 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <Trash2 className="h-4 w-4" /> Delete Pin Sensation
                    </button>
                    <button
                      onClick={() => setSelectedReading(null)}
                      className="bg-slate-950/80 border border-slate-800 text-slate-300 hover:bg-slate-900 hover:text-white text-xs px-4 rounded-xl transition-all cursor-pointer"
                    >
                      Clear Highlight
                    </button>
                  </div>
                </div>
              )}

            </div>
          </div>
        </div>

      </div>

      {/* Right Column: Somatic Stats, Milestones, and Well-being tracking card */}
      <div className="flex flex-col gap-6">
        
        {/* Streak Metrics milestone card */}
        <div className="bg-gradient-to-br from-indigo-950/30 via-slate-900/40 to-slate-900/40 border border-indigo-500/20 p-6 rounded-3xl backdrop-blur-md relative overflow-hidden">
          <div className="absolute -top-12 -right-12 w-28 h-28 bg-indigo-500/10 rounded-full blur-2xl"></div>
          
          <div className="flex items-center gap-2 mb-4">
            <Sparkles className="h-5 w-5 text-indigo-400 animate-pulse" />
            <h4 className="text-xs font-semibold uppercase tracking-[0.2em] text-indigo-300">System Milestones</h4>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-black/20 p-4 border border-slate-800/50 rounded-2xl flex flex-col justify-between">
              <span className="text-[10px] font-mono tracking-wider text-slate-500 uppercase">SENSORY LOGS</span>
              <span className="text-2xl font-sans font-bold text-slate-100 mt-2">{readings.length}</span>
              <span className="text-[9px] text-indigo-300 mt-1">Check-ins active</span>
            </div>

            <div className="bg-black/20 p-4 border border-slate-800/50 rounded-2xl flex flex-col justify-between">
              <span className="text-[10px] font-mono tracking-wider text-slate-500 uppercase">HEALING DAYS</span>
              <span className="text-2xl font-sans font-bold text-slate-100 mt-2">{calculateStreak()}</span>
              <span className="text-[9px] text-teal-300 mt-1">System streak days</span>
            </div>
          </div>
        </div>

        {/* Dynamic Well-being tracking update logger */}
        <div className="bg-slate-900/40 border border-slate-800/50 p-6 rounded-3xl backdrop-blur-md flex flex-col h-full justify-between">
          <div className="flex flex-col gap-3">
            <div className="flex items-center gap-2 border-b border-slate-800/40 pb-2.5 mb-2">
              <Smile className="h-4.5 w-4.5 text-teal-400" />
              <h4 className="text-xs font-semibold uppercase tracking-[0.2em] text-slate-300">Log Present Well-being</h4>
            </div>

            {moodLoggedToday ? (
              <div className="bg-teal-950/10 border border-teal-500/20 p-5 rounded-2xl text-center flex flex-col items-center gap-2">
                <Smile className="h-7 w-7 text-teal-400 animate-bounce" />
                <h5 className="text-xs font-sans font-semibold text-teal-300">Nervous system check-in updated!</h5>
                <p className="text-[11px] text-slate-400 leading-relaxed font-sans mt-0.5">
                  Check-in saved. You can see historical averages correlating alongside physical sensations in the **Analytics** tab.
                </p>
              </div>
            ) : (
              <form onSubmit={submitMoodLog} className="flex flex-col gap-3">
                <div className="flex flex-col gap-1">
                  <div className="flex justify-between text-[10px] font-mono tracking-wider text-slate-400">
                    <span>WELL-BEING SCALE SCORE</span>
                    <span className="text-teal-400 font-bold">{moodValue}/10</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="10"
                    value={moodValue}
                    id="dashboard-mood-slider"
                    onChange={(e) => setMoodValue(Number(e.target.value))}
                    className="w-full accent-teal-500 bg-slate-800 h-1.5 rounded cursor-pointer mt-1"
                  />
                  <div className="flex justify-between text-[8px] text-slate-500 font-mono mt-0.5">
                    <span>1 - Overwhelmed</span>
                    <span>10 - Grounded Self</span>
                  </div>
                </div>

                <div className="flex flex-col gap-1">
                  <label className="text-[9px] font-mono tracking-wider text-slate-400">EMOTIONAL DOMINANCE</label>
                  <select
                    value={moodLabel}
                    id="dashboard-mood-label"
                    onChange={(e) => setMoodLabel(e.target.value)}
                    className="bg-slate-950/80 border border-slate-800/60 text-slate-300 text-xs rounded-xl p-2 focus:outline-none focus:border-teal-500 transition-colors"
                  >
                    <option value="Calm">Calm & Present</option>
                    <option value="Anxious">Anxious & Agitated</option>
                    <option value="Stressed">Stressed / Burdened</option>
                    <option value="Angry">Angry & Reactive</option>
                    <option value="Sad">Sad & Wounded</option>
                    <option value="Numb">Numb / Blocked</option>
                    <option value="Peaceful">Peaceful / Grounded</option>
                  </select>
                </div>

                <div className="flex flex-col gap-1">
                  <label className="text-[9px] font-mono tracking-wider text-slate-400">STATE DESCRIPTION DETAILS (OPTIONAL)</label>
                  <input
                    type="text"
                    value={moodNotes}
                    id="dashboard-mood-notes"
                    onChange={(e) => setMoodNotes(e.target.value)}
                    placeholder="Briefly notes how your body is doing..."
                    className="bg-slate-950/80 border border-slate-800/60 text-slate-300 text-xs rounded-xl p-2 focus:outline-none focus:border-indigo-500 transition-colors"
                  />
                </div>

                <button
                  type="submit"
                  id="btn-submit-daily-mood"
                  className="bg-teal-600 hover:bg-teal-500 text-white text-xs font-semibold py-2.5 px-4 rounded-xl transition-all mt-1.5 cursor-pointer font-sans shadow-[0_0_12px_rgba(20,184,166,0.25)]"
                >
                  Commit Well-being Check-In
                </button>
              </form>
            )}
          </div>

          <p className="text-[10px] text-slate-500 italic mt-3 text-center leading-relaxed font-sans">
            Periodic daily check-ins align our frontal cortex memory, expanding overall thresholds of somatic tolerance.
          </p>
        </div>

      </div>

    </div>
  );
}
