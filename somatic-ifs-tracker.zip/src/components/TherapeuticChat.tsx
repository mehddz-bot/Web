import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage, IFSPart, SomaticReading } from '../types';
import { Send, Sparkles, AlertCircle, RefreshCw, Compass, Heart, MessageSquare } from 'lucide-react';

interface TherapeuticChatProps {
  parts: IFSPart[];
  readings: SomaticReading[];
}

export default function TherapeuticChat({ parts, readings }: TherapeuticChatProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "initial",
      role: 'model',
      text: "Welcome, traveler. I am here as a gentle guide in your somatic and Parts work. Before we dive deep, let's take a peaceful, slow breath together. Feel your feet and seat holding you. What physical sensations or emotional aspects are present inside your inner landscape today?",
      timestamp: new Date().toISOString()
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  // Specific IFS part or somatic check-ins focus context
  const [selectedPartId, setSelectedPartId] = useState('');
  const [selectedReadingId, setSelectedReadingId] = useState('');
  
  const bottomRef = useRef<HTMLDivElement>(null);

  // Auto scroll to latest response
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleSendMessage = async (customText?: string) => {
    const textToSend = customText || inputMessage;
    if (!textToSend.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: "user_" + Date.now(),
      role: 'user',
      text: textToSend,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMsg]);
    setInputMessage('');
    setIsLoading(true);

    // Formulate Context Info
    let contextInfo = "";
    if (selectedPartId) {
      const part = parts.find(p => p.id === selectedPartId);
      if (part) {
        contextInfo += `Session focus is on the IFS part named "${part.name}" (${part.type}). Role: "${part.role}". Safety Fear/Vulnerability: "${part.fear}". Associated somatic locations: ${part.associatedSensations?.join(', ') || 'none'}.`;
      }
    }
    if (selectedReadingId) {
      const read = readings.find(r => r.id === selectedReadingId);
      if (read) {
        contextInfo += `Session focus is on the physical sensation logged in the "${read.location}" with intensity level ${read.intensity}/10 holding emotion "${read.associatedEmotion}". Sensation characteristics: "${read.type}". Description: "${read.notes || 'None'}".`;
      }
    }

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          messages: [...messages, userMsg].map(m => ({ role: m.role, text: m.text })),
          contextInfo
        })
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData?.error || "Failed API request");
      }

      const botReply: ChatMessage = await response.json();
      setMessages(prev => [...prev, botReply]);
    } catch (e: any) {
      console.error(e);
      setMessages(prev => [
        ...prev,
        {
          id: "err_" + Date.now(),
          role: 'model',
          text: `[SYSTEM CONNECTION FAILURE] I am having trouble connecting to the backend Gemini AI server. Please make sure you have supplied a valid \`GEMINI_API_KEY\` secret in the **Settings > Secrets** panel of the AI Studio UI.\n\nError: ${e?.message || e}`,
          timestamp: new Date().toISOString()
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClearChat = () => {
    setMessages([
      {
        id: "initial_reset",
        role: 'model',
        text: "I have gathered our space once again. Take a slow, settling deep breath. How can I guide you somatically or facilitate conversations with your protective parts in this spacious moment?",
        timestamp: new Date().toISOString()
      }
    ]);
    setSelectedPartId('');
    setSelectedReadingId('');
  };

  // Quick prompt buttons
  const PRES_GROUND = "I am feeling emotionally flooded and overwhelmed. Please guide me through an immediate somatic grounding practice.";
  const PRES_CRITIC = "I have identified an active, harsh Inner Critic protector part. Can you help me find out what it is afraid would happen if it stopped criticizing me?";
  const PRES_TRACKING = "I can feel a strong, uncomfortable sensation in my body right now. Guide me through the somatic tracking cycle to safely befriend it.";
  const PRES_APPRECIATE = "I want to express appreciation to a hard-working protector part of me for keeping me safe, but I need guidance on how to speak with it.";

  return (
    <div className="bg-slate-900/40 border border-slate-800 rounded-2xl backdrop-blur-md shadow-lg flex flex-col h-[580px]">
      
      {/* Header Context panel */}
      <div className="border-b border-slate-800 px-5 py-3.5 flex flex-col md:flex-row md:items-center justify-between gap-3 bg-slate-950/20">
        <div className="flex items-center gap-2">
          <MessageSquare className="h-4.5 w-4.5 text-indigo-400 animate-pulse" />
          <h4 className="font-sans font-medium text-sm text-slate-200">Empathic Somatic & IFS AI Guide</h4>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="clear-chat-logs-btn"
            onClick={handleClearChat}
            className="flex items-center gap-1.5 text-[10px] font-mono text-slate-500 hover:text-rose-400 transition-colors px-2.5 py-1 bg-slate-900/40 rounded border border-slate-800 cursor-pointer"
          >
            <RefreshCw className="h-3 w-3" /> Clear Dialogue Space
          </button>
        </div>
      </div>

      {/* Target Focus assignment area */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 px-5 py-3 border-b border-slate-850 bg-slate-950/40">
        <div className="flex flex-col gap-1">
          <label className="text-[9px] font-mono text-slate-500">FOCUS DIALOGUE ON ACTIVE PART</label>
          <select
            value={selectedPartId}
            id="chat-focus-part-select"
            onChange={(e) => {
              setSelectedPartId(e.target.value);
              // Set message helper context note in log
              if (e.target.value) {
                const targetName = parts.find(p => p.id === e.target.value)?.name;
                setMessages(prev => [
                  ...prev,
                  {
                    id: "meta_" + Date.now(),
                    role: 'model',
                    text: `*Aesthetic Focus update: We are now directing our loving inquiry toward "${targetName}". Let's take a breath, soften, and look at how we feel towards this protector.*`,
                    timestamp: new Date().toISOString()
                  }
                ]);
              }
            }}
            className="w-full bg-slate-950/80 border border-slate-800 text-slate-300 text-xs rounded px-2 py-1.5 focus:outline-none"
          >
            <option value="">-- No protective part selection --</option>
            {parts.map(p => (
              <option key={p.id} value={p.id}>{p.name} ({p.type})</option>
            ))}
          </select>
        </div>

        <div className="flex flex-col gap-1">
          <label className="text-[9px] font-mono text-slate-500">FOCUS DIALOGUE ON SOMATIC SENSATION</label>
          <select
            value={selectedReadingId}
            id="chat-focus-sensation-select"
            onChange={(e) => {
              setSelectedReadingId(e.target.value);
              if (e.target.value) {
                const targetLoc = readings.find(r => r.id === e.target.value);
                if (targetLoc) {
                  setMessages(prev => [
                    ...prev,
                    {
                      id: "meta_" + Date.now(),
                      role: 'model',
                      text: `*Aesthetic Focus update: We are now focusing on the physical feeling in your "${targetLoc.location}" (${targetLoc.type}, intensity ${targetLoc.intensity}/10). Let's let our physical awareness gather there gently.*`,
                      timestamp: new Date().toISOString()
                    }
                  ]);
                }
              }
            }}
            className="w-full bg-slate-950/80 border border-slate-800 text-slate-300 text-xs rounded px-2 py-1.5 focus:outline-none"
          >
            <option value="">-- No physical canvas sensation selection --</option>
            {readings.map(r => {
              const d = new Date(r.timestamp).toLocaleDateString();
              return (
                <option key={r.id} value={r.id}>{d} - {r.location} {r.type} (lvl {r.intensity})</option>
              );
            })}
          </select>
        </div>
      </div>

      {/* Messages layout */}
      <div className="flex-1 overflow-y-auto p-5 space-y-4">
        {messages.map((m) => {
          const isSystemMeta = m.text.startsWith('*') && m.text.endsWith('*');
          const isAi = m.role === 'model';
          const isErrorMsg = m.text.includes('[SYSTEM CONNECTION FAILURE]');

          return (
            <div
              key={m.id}
              className={`flex flex-col max-w-[85%] ${isAi ? 'mr-auto items-start' : 'ml-auto items-end'}`}
            >
              {isSystemMeta ? (
                <span className="text-xs text-indigo-400 italic font-sans py-1 leading-relaxed text-center px-4 w-full block">
                  {m.text}
                </span>
              ) : (
                <div
                  className={`p-4 rounded-2xl text-xs leading-relaxed font-sans ${
                    isAi
                      ? isErrorMsg
                        ? 'bg-rose-950/30 border border-rose-900/40 text-rose-200'
                        : 'bg-slate-950/60 border border-slate-850 text-slate-100'
                      : 'bg-indigo-600 border border-indigo-500 text-white'
                  }`}
                >
                  {isAi && (
                    <div className="flex items-center gap-1.5 text-[9px] font-mono tracking-wider font-semibold text-indigo-300 uppercase mb-2">
                      <Sparkles className="h-3 w-3 animate-spin-slow" /> Therapist Guide
                    </div>
                  )}
                  <p className="whitespace-pre-line font-light">{m.text}</p>
                </div>
              )}
              <span className="text-[10px] font-mono text-slate-500 mt-1 pl-2">
                {new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          );
        })}

        {isLoading && (
          <div className="flex flex-col max-w-[85%] mr-auto items-start">
            <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-850 text-slate-400 font-sans text-xs flex items-center gap-2">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-500"></span>
              </span>
              <span>Guidance connection focusing on your inner psyche system...</span>
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Grounding Quick Presets slider row */}
      {messages.length < 5 && (
        <div className="px-5 py-2.5 bg-slate-950/30 border-t border-slate-850 overflow-x-auto whitespace-nowrap flex gap-2 scrollbar-none">
          <button
            onClick={() => handleSendMessage(PRES_GROUND)}
            className="inline-flex items-center gap-1.5 bg-rose-950/30 border border-rose-900/50 hover:bg-rose-900/30 text-rose-200 px-3 py-1.5 rounded-lg text-[10px] cursor-pointer font-sans"
          >
            <AlertCircle className="h-3.5 w-3.5" /> Direct Grounding Loop
          </button>
          <button
            onClick={() => handleSendMessage(PRES_TRACKING)}
            className="inline-flex items-center gap-1.5 bg-teal-950/30 border border-teal-900/50 hover:bg-teal-900/30 text-teal-200 px-3 py-1.5 rounded-lg text-[10px] cursor-pointer font-sans"
          >
            <Compass className="h-3.5 w-3.5 animate-spin-slow" /> Somatic Tracking Loop
          </button>
          <button
            onClick={() => handleSendMessage(PRES_CRITIC)}
            className="inline-flex items-center gap-1.5 bg-blue-950/30 border border-blue-900/50 hover:bg-blue-900/30 text-blue-200 px-3 py-1.5 rounded-lg text-[10px] cursor-pointer font-sans"
          >
            <Heart className="h-3.5 w-3.5" /> Dialogue Inner Critic
          </button>
        </div>
      )}

      {/* Form Input row */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSendMessage();
        }}
        className="p-3.5 border-t border-slate-800 bg-slate-950/20 flex gap-3.5 items-center"
      >
        <input
          type="text"
          value={inputMessage}
          id="chat-user-message-input"
          onChange={(e) => setInputMessage(e.target.value)}
          placeholder={selectedPartId ? "Dialogue with your active protector..." : "How do you feel towards the somatic sensation right now?"}
          className="flex-1 bg-slate-950/70 border border-slate-800 rounded-xl px-4 py-3 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-sans"
          disabled={isLoading}
        />
        <button
          type="submit"
          id="chat-send-msg-btn"
          disabled={!inputMessage.trim() || isLoading}
          className="p-3 bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-500 hover:to-indigo-600 rounded-xl text-white transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
        >
          <Send className="h-4.5 w-4.5" />
        </button>
      </form>
    </div>
  );
}
