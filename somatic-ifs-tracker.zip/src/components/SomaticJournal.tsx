import React, { useState } from 'react';
import { JournalEntry, IFSPart, SomaticReading } from '../types';
import { BookOpen, Search, Plus, Calendar, Smile, Compass, Heart, Trash2, ArrowLeft } from 'lucide-react';

interface SomaticJournalProps {
  journals: JournalEntry[];
  parts: IFSPart[];
  readings: SomaticReading[];
  onAddJournal: (journal: Omit<JournalEntry, 'id' | 'timestamp'>) => void;
  onDeleteJournal: (id: string) => void;
}

export default function SomaticJournal({
  journals,
  parts,
  readings,
  onAddJournal,
  onDeleteJournal,
}: SomaticJournalProps) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [moodValue, setMoodValue] = useState<number>(6);
  const [associatedPartId, setAssociatedPartId] = useState<string>('');
  const [associatedSensationId, setAssociatedSensationId] = useState<string>('');

  const handleCreateJournal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !body) return;

    onAddJournal({
      title,
      body,
      moodValue,
      associatedPartId: associatedPartId || undefined,
      associatedSensationId: associatedSensationId || undefined,
    });

    // Reset
    setTitle('');
    setBody('');
    setMoodValue(6);
    setAssociatedPartId('');
    setAssociatedSensationId('');
    setShowAddForm(false);
  };

  const getMoodEmoji = (val: number) => {
    if (val >= 8) return '🌱 Grounded (Calm)';
    if (val >= 6) return '🧘 Steady (Neutral)';
    if (val >= 4) return '⚡ Hyper-Aroused (Anxious/Agitated)';
    return '🌀 Hypo-Aroused (Numb/Depressed)';
  };

  const formatDate = (isoStr: string) => {
    try {
      const d = new Date(isoStr);
      return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' });
    } catch (e) {
      return '';
    }
  };

  // Filters journals matching search
  const filteredJournals = journals.filter(j => {
    const q = searchQuery.toLowerCase();
    return (
      j.title.toLowerCase().includes(q) ||
      j.body.toLowerCase().includes(q) ||
      parts.find(p => p.id === j.associatedPartId)?.name.toLowerCase().includes(q)
    );
  });

  return (
    <div className="flex flex-col gap-6 h-full">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h3 className="text-xl font-sans font-medium text-slate-100 flex items-center gap-2">
            <BookOpen className="h-5 w-5 text-indigo-400" />
            Ventral Narrative Journal
          </h3>
          <p className="text-xs text-slate-400 mt-1 max-w-xl leading-relaxed font-sans">
            Refining raw somatic awareness into conscious narrative words. Integrating the voices of your reactive or burdened parts and anchoring them in the loving presence of 'Self-energy'.
          </p>
        </div>

        <button
          id="btn-trigger-add-journal"
          onClick={() => setShowAddForm(!showAddForm)}
          className="flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-xs px-4 py-2.5 rounded-lg transition-colors cursor-pointer shrink-0 font-sans shadow-md"
        >
          {showAddForm ? 'Back to Journal List' : <><Plus className="h-4 w-4" /> Create Journal Entry</>}
        </button>
      </div>

      {showAddForm ? (
        /* Create Journal Entry Form */
        <form onSubmit={handleCreateJournal} className="bg-slate-900/50 border border-slate-800 p-6 rounded-2xl backdrop-blur-md max-w-2xl mx-auto w-full flex flex-col gap-4">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-3 mb-2">
            <BookOpen className="h-4.5 w-4.5 text-indigo-400 animate-pulse" />
            <h4 className="text-sm font-sans font-medium text-slate-200">Reflect, Listen, and Integrate</h4>
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-mono text-slate-400">ENTRY TITLE</label>
            <input
              type="text"
              value={title}
              id="journal-title-input"
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Dialogue with the Perfectionist, Befriending the Chest Tightness"
              className="bg-slate-950/70 border border-slate-800 text-slate-200 text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-indigo-500 font-sans"
              required
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-mono text-slate-400">NARRATIVE BODY</label>
            <textarea
              value={body}
              id="journal-body-input"
              onChange={(e) => setBody(e.target.value)}
              placeholder="Describe your inner inquiry. What thoughts arose? What were your physical sensations telling you? If you dialogued with an IFS part, write the conversation down verbatim..."
              className="bg-slate-950/70 border border-slate-800 text-slate-200 text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-indigo-500 font-sans min-h-[140px] leading-relaxed"
              required
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-mono text-slate-400">LINK IFS PROTECTION PART (OPTIONAL)</label>
              <select
                value={associatedPartId}
                id="journal-part-select"
                onChange={(e) => setAssociatedPartId(e.target.value)}
                className="bg-slate-950/70 border border-slate-800 text-slate-200 text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-indigo-500 font-sans"
              >
                <option value="">No associated sub-self part</option>
                {parts.map((p) => (
                  <option key={p.id} value={p.id}>{p.name} ({p.type})</option>
                ))}
              </select>
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-mono text-slate-400">LINK SOMATIC READING (OPTIONAL)</label>
              <select
                value={associatedSensationId}
                id="journal-somatic-select"
                onChange={(e) => setAssociatedSensationId(e.target.value)}
                className="bg-slate-950/70 border border-slate-800 text-slate-200 text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-indigo-500 font-sans"
              >
                <option value="">No associated somatic canvas log</option>
                {readings.map((r) => {
                  const day = new Date(r.timestamp).toLocaleDateString('en', { month: 'short', day: 'numeric' });
                  return (
                    <option key={r.id} value={r.id}>
                      {day} - {r.location} {r.type} (lvl {r.intensity})
                    </option>
                  );
                })}
              </select>
            </div>
          </div>

          {/* Slider for well-being mood tracking */}
          <div className="flex flex-col gap-1.5 mt-2 p-3.5 bg-slate-950/40 border border-slate-800 rounded-lg">
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-mono text-slate-400">OVERALL INNER REGULATION STATE</label>
              <span className="text-xs text-indigo-300 font-medium font-sans">{getMoodEmoji(moodValue)}</span>
            </div>
            
            <input
              type="range"
              min="1"
              max="10"
              value={moodValue}
              id="journal-mood-slider"
              onChange={(e) => setMoodValue(Number(e.target.value))}
              className="w-full accent-indigo-500 bg-slate-800 h-1.5 rounded-lg appearance-none cursor-pointer mt-2"
            />
            
            <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-1">
              <span>1 - Frozen/Numb</span>
              <span>5 - Neutral</span>
              <span>10 - Self Presence</span>
            </div>
          </div>

          <div className="flex gap-4 mt-2">
            <button
              type="submit"
              id="btn-journal-submit"
              className="flex-1 bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-500 hover:to-indigo-600 font-sans font-medium text-sm text-white py-2.5 rounded-xl cursor-pointer"
            >
              Commit Journal to Log Memory
            </button>
            <button
              type="button"
              id="btn-journal-cancel"
              onClick={() => setShowAddForm(false)}
              className="bg-slate-950/80 border border-slate-800 hover:bg-slate-850 px-4 py-2 text-slate-400 text-sm font-sans font-medium rounded-xl hover:text-slate-200 cursor-pointer"
            >
              Cancel
            </button>
          </div>
        </form>
      ) : (
        /* Journal list viewing */
        <div className="flex flex-col gap-6">
          
          {/* Search filter row */}
          <div className="relative">
            <Search className="absolute left-3.5 top-3.5 h-4.5 w-4.5 text-slate-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search journals by title, content, linked parts..."
              className="w-full bg-slate-900/40 border border-slate-800 rounded-xl pl-10 pr-4 py-3 text-sm text-slate-200 focus:outline-none focus:border-indigo-500 font-sans"
            />
          </div>

          {filteredJournals.length === 0 ? (
            <div className="flex flex-col items-center justify-center p-20 bg-slate-900/10 border border-dashed border-slate-800/80 rounded-2xl text-center">
              <BookOpen className="h-8 w-8 text-slate-700 mb-2 animate-pulse" />
              <h5 className="text-sm font-sans font-semibold text-slate-400">No narrative entries matched</h5>
              <p className="text-xs text-slate-500 mt-1 max-w-sm">
                Try logging your first reflection to combine physical sensations with part exploration narratives.
              </p>
            </div>
          ) : (
            <div className="flex flex-col gap-4">
              {filteredJournals.map((journal) => {
                const stepPart = parts.find(p => p.id === journal.associatedPartId);
                const stepReading = readings.find(r => r.id === journal.associatedSensationId);

                return (
                  <div
                    key={journal.id}
                    className="bg-slate-900/30 border border-slate-800 hover:border-slate-700/80 p-5 rounded-xl flex flex-col md:flex-row gap-5 transition-all duration-300 relative"
                  >
                    {/* Left Column Meta */}
                    <div className="w-full md:w-48 shrink-0 flex flex-col gap-2 border-b md:border-b-0 md:border-r border-slate-800 md:pr-4">
                      <div className="flex items-center gap-1.5 text-slate-400 font-sans text-xs">
                        <Calendar className="h-3.5 w-3.5 text-slate-500" />
                        <span>{formatDate(journal.timestamp)}</span>
                      </div>
                      
                      {journal.moodValue !== undefined && (
                        <div className="flex items-center gap-1.5 text-slate-300 font-sans text-xs">
                          <Smile className="h-3.5 w-3.5 text-teal-400" />
                          <span>Lvl {journal.moodValue} Wellbeing</span>
                        </div>
                      )}

                      {/* Connected entities icons */}
                      <div className="flex flex-col gap-1.5 mt-2">
                        {stepPart && (
                          <div className="flex items-center gap-1.5 bg-indigo-950/40 border border-indigo-900/40 px-2 py-1 rounded-md text-[10px] text-indigo-300 w-fit font-sans">
                            <Heart className="h-3 w-3" />
                            <span className="truncate max-w-[120px]">{stepPart.name}</span>
                          </div>
                        )}
                        {stepReading && (
                          <div className="flex items-center gap-1.5 bg-teal-950/40 border border-teal-900/40 px-2 py-1 rounded-md text-[10px] text-teal-300 w-fit font-sans">
                            <Compass className="h-3 w-3 animate-spin-slow" />
                            <span className="capitalize">{stepReading.location} ({stepReading.type})</span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Right column text */}
                    <div className="flex-1 flex flex-col justify-between">
                      <div>
                        <h4 className="font-sans font-medium text-slate-100 text-base">{journal.title}</h4>
                        <p className="text-xs text-slate-300 leading-relaxed font-sans mt-3 whitespace-pre-line font-light">
                          {journal.body}
                        </p>
                      </div>

                      <div className="flex justify-end mt-4 pt-2 border-t border-slate-900">
                        <button
                          onClick={() => onDeleteJournal(journal.id)}
                          className="flex items-center gap-1.5 text-slate-600 hover:text-red-400 transition-colors text-xs font-mono py-1 rounded cursor-pointer"
                          title="Delete entry"
                        >
                          <Trash2 className="h-3.5 w-3.5" /> Remove entry
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

        </div>
      )}
    </div>
  );
}
