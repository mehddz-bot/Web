import React from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { SomaticReading, MoodLog } from '../types';
import { BarChart3, TrendingUp, Compass, AlertCircle, PieChart as PieIcon } from 'lucide-react';

interface SomaticChartsProps {
  readings: SomaticReading[];
  moodLogs: MoodLog[];
}

export default function SomaticCharts({ readings, moodLogs }: SomaticChartsProps) {
  
  // Format data for timeline trend
  // Let's combine mood and somatic logs by day
  const getTimelineData = () => {
    const datesMap: { [key: string]: { date: string; moodTotal: number; moodCount: number; somTotal: number; somCount: number } } = {};

    // Helper to format ISO to short date e.g. "May 20"
    const formatDate = (isoStr: string) => {
      try {
        const d = new Date(isoStr);
        return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
      } catch (e) {
        return '';
      }
    };

    // Sort logs chronologically to compute trends
    const allDates: string[] = [];

    // Process mood logs (last 10 logs)
    const sortedMoods = [...moodLogs].sort((a,b)=> new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()).slice(-10);
    sortedMoods.forEach(m => {
      const day = formatDate(m.timestamp);
      if (!day) return;
      if (!datesMap[day]) {
        datesMap[day] = { date: day, moodTotal: 0, moodCount: 0, somTotal: 0, somCount: 0 };
        allDates.push(day);
      }
      datesMap[day].moodTotal += m.value;
      datesMap[day].moodCount += 1;
    });

    // Process somatic readings (last 15 somatic entries)
    const sortedReadings = [...readings].sort((a,b)=> new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()).slice(-15);
    sortedReadings.forEach(s => {
      const day = formatDate(s.timestamp);
      if (!day) return;
      if (!datesMap[day]) {
        datesMap[day] = { date: day, moodTotal: 0, moodCount: 0, somTotal: 0, somCount: 0 };
        allDates.push(day);
      }
      datesMap[day].somTotal += s.intensity;
      datesMap[day].somCount += 1;
    });

    // Translate to recharts array
    return Object.values(datesMap).map(dayObj => ({
      date: dayObj.date,
      "Well-being (Mood)": dayObj.moodCount > 0 ? Number((dayObj.moodTotal / dayObj.moodCount).toFixed(1)) : null,
      "Somatic Intensity": dayObj.somCount > 0 ? Number((dayObj.somTotal / dayObj.somCount).toFixed(1)) : null,
    }));
  };

  // Sensation Type counts
  const getSensationTypeData = () => {
    const counts: { [key: string]: number } = {
      tightness: 0,
      tingling: 0,
      heaviness: 0,
      heat: 0,
      cold: 0,
      numbness: 0,
      fluttering: 0,
      pulsing: 0,
    };

    readings.forEach(s => {
      if (counts[s.type] !== undefined) {
        counts[s.type] += 1;
      }
    });

    return Object.entries(counts).map(([name, count]) => ({
      name: name.charAt(0).toUpperCase() + name.slice(1),
      Count: count
    })).filter(item => item.Count > 0);
  };

  // Associated Emotion Pie Data
  const getEmotionPieData = () => {
    const emotionsMap: { [key: string]: number } = {};
    readings.forEach(s => {
      const emo = s.associatedEmotion || "Unknown";
      emotionsMap[emo] = (emotionsMap[emo] || 0) + 1;
    });

    return Object.entries(emotionsMap).map(([name, value]) => ({
      name,
      value
    }));
  };

  const timelineData = getTimelineData();
  const sensationData = getSensationTypeData();
  const emotionPieData = getEmotionPieData();

  // Emotion Colors matched to BodyMap legend
  const EMOTION_COLORS: { [key: string]: string } = {
    Fear: '#f59e0b', // amber
    Anger: '#ef4444', // red
    Grief: '#3b82f6', // blue
    Shame: '#8b5cf6', // purple
    Guilt: '#6366f1', // indigo
    Joy: '#10b981', // emerald
    Peace: '#14b8a6', // teal
  };

  const DEFAULT_COLORS = ['#3b82f6', '#10b981', '#8b5cf6', '#f59e0b', '#ec4899', '#14b8a6'];

  return (
    <div className="flex flex-col gap-8 h-full">
      <div>
        <h3 className="text-xl font-sans font-medium text-slate-100 flex items-center gap-2">
          <BarChart3 className="h-5 w-5 text-indigo-400" />
          Nervous System Analytics
        </h3>
        <p className="text-xs text-slate-400 mt-1 max-w-xl font-sans">
          Observe the underlying patterns of your somatic-emotional landscape. Notice how physical tightness corresponds with mood swings over time.
        </p>
      </div>

      {readings.length === 0 && moodLogs.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 bg-slate-900/40 rounded-2xl border border-slate-800 text-center">
          <AlertCircle className="h-8 w-8 text-slate-600 mb-2 animate-bounce" />
          <h4 className="text-sm font-sans font-semibold text-slate-400">Not Enough Data Logged Yet</h4>
          <p className="text-xs text-slate-500 mt-1 max-w-[280px]">
            Once you log a few mood updates and add somatic sensations, beautiful correlation charts will populate here.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* Chart 1: Well-being vs Somatic intensity over time */}
          <div className="bg-slate-900/40 border border-slate-800/80 p-5 rounded-2xl backdrop-blur-md flex flex-col h-80">
            <h4 className="text-xs font-mono text-slate-400 uppercase tracking-wider mb-4 flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-indigo-400" />
              Mind-Body Correlation Trend
            </h4>
            <div className="flex-1 w-full text-xs">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={timelineData} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid stroke="#1e293b" vertical={false} />
                  <XAxis dataKey="date" stroke="#64748b" dy={10} axisLine={false} tickLine={false} />
                  <YAxis domain={[0, 10]} stroke="#64748b" axisLine={false} tickLine={false} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#020617', borderColor: '#1e293b', borderRadius: '8px' }}
                    labelStyle={{ color: '#94a3b8', fontFamily: 'monospace', fontSize: '10px' }}
                  />
                  <Legend verticalAlign="top" height={36} iconType="circle" wrapperStyle={{ paddingBottom: '10px' }} />
                  <Line
                    type="monotone"
                    dataKey="Well-being (Mood)"
                    stroke="#10b981"
                    strokeWidth={2.5}
                    dot={{ r: 4, strokeWidth: 1 }}
                    activeDot={{ r: 6 }}
                    connectNulls
                  />
                  <Line
                    type="monotone"
                    dataKey="Somatic Intensity"
                    stroke="#f43f5e"
                    strokeWidth={2.5}
                    dot={{ r: 4, strokeWidth: 1 }}
                    activeDot={{ r: 6 }}
                    connectNulls
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
            <p className="text-[10px] text-slate-500 italic text-center mt-3 font-sans">
              *Lower intensity somatic values generally lead to higher overall wellbeing scores.
            </p>
          </div>

          {/* Chart 2: Sensation Typology Breakdown */}
          <div className="bg-slate-900/40 border border-slate-800/80 p-5 rounded-2xl backdrop-blur-md flex flex-col h-80">
            <h4 className="text-xs font-mono text-slate-400 uppercase tracking-wider mb-4 flex items-center gap-2 animate-pulse">
              <Compass className="h-4 w-4 text-indigo-400" />
              Somatic Typology Breakdown
            </h4>
            {sensationData.length === 0 ? (
              <div className="flex-1 flex items-center justify-center text-slate-600 text-xs italic font-sans">
                No active sensations discovered yet.
              </div>
            ) : (
              <div className="flex-1 w-full text-xs">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={sensationData} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid stroke="#1e293b" vertical={false} />
                    <XAxis dataKey="name" stroke="#64748b" axisLine={false} tickLine={false} dy={5} />
                    <YAxis allowDecimals={false} stroke="#64748b" axisLine={false} tickLine={false} />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#020617', borderColor: '#1e293b', borderRadius: '8px' }}
                      cursor={{ fill: '#1e293b', opacity: 0.3 }}
                    />
                    <Bar dataKey="Count" fill="#4f46e5" radius={[4, 4, 0, 0]} maxBarSize={45}>
                      {sensationData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={DEFAULT_COLORS[index % DEFAULT_COLORS.length]} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
            <p className="text-[10px] text-slate-500 italic text-center mt-3 font-sans">
              *Shows frequency counts of physical traits logged in the body canvas.
            </p>
          </div>

          {/* Chart 3: Emotions Correlation Pie */}
          <div className="bg-slate-900/40 border border-slate-800/80 p-5 rounded-2xl backdrop-blur-md flex flex-col h-80 lg:col-span-2 max-w-2xl mx-auto w-full">
            <h4 className="text-xs font-mono text-slate-400 uppercase tracking-wider mb-4 flex items-center gap-2">
              <PieIcon className="h-4 w-4 text-indigo-400" />
              Nervous System Emotional Load
            </h4>
            {emotionPieData.length === 0 ? (
              <div className="flex-1 flex items-center justify-center text-slate-600 text-xs italic font-sans">
                No emotions currently mapped.
              </div>
            ) : (
              <div className="flex-1 flex flex-col md:flex-row items-center justify-center gap-6">
                <div className="w-48 h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={emotionPieData}
                        cx="50%"
                        cy="50%"
                        innerRadius={55}
                        outerRadius={75}
                        paddingAngle={4}
                        dataKey="value"
                      >
                        {emotionPieData.map((entry, index) => (
                          <Cell 
                            key={`cell-${index}`} 
                            fill={EMOTION_COLORS[entry.name] || DEFAULT_COLORS[index % DEFAULT_COLORS.length]} 
                          />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{ backgroundColor: '#020617', borderColor: '#1e293b', borderRadius: '8px' }}
                        itemStyle={{ fontSize: '11px' }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>

                {/* Legend details custom card */}
                <div className="flex-1 grid grid-cols-2 md:grid-cols-3 gap-2 text-xs">
                  {emotionPieData.map((d, i) => {
                    const color = EMOTION_COLORS[d.name] || DEFAULT_COLORS[i % DEFAULT_COLORS.length];
                    const total = emotionPieData.reduce((acc, curr) => acc + curr.value, 0);
                    const pct = ((d.value / total) * 100).toFixed(0);

                    return (
                      <div key={d.name} className="flex items-center gap-2.5 bg-slate-950/20 border border-slate-800/50 p-2 rounded-lg font-sans">
                        <span className="h-2.5 w-2.5 rounded-full shrink-0" style={{ backgroundColor: color }}></span>
                        <div className="flex flex-col">
                          <span className="font-medium text-slate-200">{d.name}</span>
                          <span className="text-[10px] font-mono text-slate-400">{pct}% ({d.value} logs)</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

        </div>
      )}
    </div>
  );
}
