import React, { useState } from 'react';
import { IFSPart, PartType } from '../types';
import { Shield, Flame, User, Sparkles, Plus, Trash2, Heart, HelpCircle } from 'lucide-react';

interface PartsManagerProps {
  parts: IFSPart[];
  onAddPart: (part: Omit<IFSPart, 'id' | 'createdAt'>) => void;
  onDeletePart: (id: string) => void;
}

export default function PartsManager({ parts, onAddPart, onDeletePart }: PartsManagerProps) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [name, setName] = useState('');
  const [type, setType] = useState<PartType>('manager');
  const [role, setRole] = useState('');
  const [fear, setFear] = useState('');
  const [newSensation, setNewSensation] = useState('');
  const [associatedSensations, setAssociatedSensations] = useState<string[]>([]);
  const [color, setColor] = useState('blue');

  const handleCreatePart = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !role) return;

    onAddPart({
      name,
      type,
      role,
      fear,
      associatedSensations: associatedSensations.length > 0 ? associatedSensations : [newSensation].filter(Boolean),
      color
    });

    // Reset Form
    setName('');
    setRole('');
    setFear('');
    setNewSensation('');
    setAssociatedSensations([]);
    setShowAddForm(false);
  };

  const addSensationChip = () => {
    if (newSensation.trim()) {
      setAssociatedSensations([...associatedSensations, newSensation.trim()]);
      setNewSensation('');
    }
  };

  const removeSensationChip = (idx: number) => {
    setAssociatedSensations(associatedSensations.filter((_, i) => i !== idx));
  };

  const getPartTypeStyles = (type: PartType) => {
    switch (type) {
      case 'manager':
        return {
          icon: <Shield className="h-4.5 w-4.5 text-blue-400" />,
          bgColor: 'bg-blue-500/10 border-blue-900/40 text-blue-200',
          badge: 'bg-blue-950/80 border-blue-900/50 text-blue-300',
          title: 'Protector: Manager',
          desc: 'Proactive protector. Keeps you safe by planning, controlling, criticizing, and working hard.'
        };
      case 'firefighter':
        return {
          icon: <Flame className="h-4.5 w-4.5 text-rose-400" />,
          bgColor: 'bg-rose-500/10 border-rose-900/40 text-rose-200',
          badge: 'bg-rose-950/80 border-rose-900/50 text-rose-300',
          title: 'Protector: Firefighter',
          desc: 'Reactive protector. Rescues you with dissociation, numbing, scrolling, or substance when pain spills over.'
        };
      case 'exile':
        return {
          icon: <User className="h-4.5 w-4.5 text-violet-400" />,
          bgColor: 'bg-violet-500/10 border-violet-900/40 text-violet-200',
          badge: 'bg-violet-950/80 border-violet-900/50 text-violet-300',
          title: 'Wounded Exile',
          desc: 'Vulnerable younger part. Holds memory seeds of shame, grief, rejection, and absolute unlovability from the past.'
        };
    }
  };

  return (
    <div className="flex flex-col gap-6 h-full">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h3 className="text-xl font-sans font-medium text-slate-100 flex items-center gap-2">
            <Heart className="h-5 w-5 text-indigo-400" />
            IFS Sub-Self Parts Manager
          </h3>
          <p className="text-xs text-slate-400 mt-1 max-w-xl leading-relaxed font-sans">
            In IFS therapy, we are not a single monolith—we contain multiple sub-selves or 'Parts', each with positive intention. Identify your active protectors and heal your wounded exiles.
          </p>
        </div>

        <button
          id="btn-trigger-add-part-form"
          onClick={() => setShowAddForm(!showAddForm)}
          className="flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-xs px-4 py-2.5 rounded-lg transition-colors cursor-pointer shrink-0 font-sans shadow-md"
        >
          {showAddForm ? 'View Parts List' : <><Plus className="h-4 w-4" /> Discover New Part</>}
        </button>
      </div>

      {showAddForm ? (
        /* Discovery form of an IFS Part */
        <form onSubmit={handleCreatePart} className="bg-slate-900/50 border border-slate-800 p-6 rounded-2xl backdrop-blur-md max-w-2xl mx-auto w-full flex flex-col gap-4">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-3 mb-2">
            <Sparkles className="h-4 w-4 text-indigo-400 animate-pulse" />
            <h4 className="text-sm font-sans font-medium text-slate-200">Map an Internal Protector or Exile</h4>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-mono text-slate-400">PART NAME OR IDENTIFIER</label>
              <input
                type="text"
                value={name}
                id="ifs-part-name-input"
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. The Harsh Critic, The Numbing Jester, Little Bobby"
                className="bg-slate-950/70 border border-slate-800 text-slate-200 text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-indigo-500 font-sans"
                required
              />
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-mono text-slate-400">IFS SYSTEM ARCHETYPE</label>
              <select
                value={type}
                id="ifs-part-type-input"
                onChange={(e) => setType(e.target.value as PartType)}
                className="bg-slate-950/70 border border-slate-800 text-slate-200 text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-indigo-500 font-sans"
              >
                <option value="manager">Manager (Proactive Safety)</option>
                <option value="firefighter">Firefighter (Reactive Rescue)</option>
                <option value="exile">Exile (Core Burdens/Wound)</option>
              </select>
            </div>
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-mono text-slate-400">CORE JOB ROLE / INTENTION</label>
            <textarea
              value={role}
              id="ifs-part-role-input"
              onChange={(e) => setRole(e.target.value)}
              placeholder="What job does this part perform in your life? (e.g. 'Relentlessly criticizes body image to force health checks before someone rejects us.')"
              className="bg-slate-950/70 border border-slate-800 text-slate-200 text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-indigo-500 font-sans min-h-[60px]"
              required
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-mono text-slate-400">CORE SYSTEM PROTECTION FEAR</label>
            <textarea
              value={fear}
              id="ifs-part-fear-input"
              onChange={(e) => setFear(e.target.value)}
              placeholder="What is this part terrified would happen to you if it stopped doing this job? (e.g. 'I am afraid I will be completely overwhelmed and die of grief.')"
              className="bg-slate-950/70 border border-slate-800 text-slate-200 text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-indigo-500 font-sans min-h-[60px]"
              required
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-mono text-slate-400">ASSOCIATED SOMATIC FOOTPRINT (SENSATIONS)</label>
            <div className="flex gap-2">
              <input
                type="text"
                value={newSensation}
                id="ifs-part-somatic-element"
                onChange={(e) => setNewSensation(e.target.value)}
                placeholder="e.g. tight stomach, lump in throat, clenched jaw"
                className="flex-1 bg-slate-950/70 border border-slate-800 text-slate-200 text-xs rounded-lg px-3 py-2 focus:outline-none focus:border-indigo-500 font-sans"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addSensationChip();
                  }
                }}
              />
              <button
                type="button"
                id="btn-add-somatic-tag"
                onClick={addSensationChip}
                className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-xs px-3 rounded-lg border border-slate-700 transition-colors cursor-pointer"
              >
                Add Tag
              </button>
            </div>
            
            {associatedSensations.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mt-2">
                {associatedSensations.map((sens, idx) => (
                  <span key={idx} className="flex items-center gap-1.5 bg-slate-950/90 text-indigo-300 border border-indigo-900/60 text-[10px] font-mono pl-2 pr-1.5 py-1 rounded-full">
                    {sens}
                    <button
                      type="button"
                      onClick={() => removeSensationChip(idx)}
                      className="text-slate-500 hover:text-rose-400 font-bold ml-1 text-xs"
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-mono text-slate-400">REPRESENTATION CARDS COLOR</label>
            <div className="flex bg-slate-950/40 p-2.5 border border-slate-800 rounded-lg gap-4">
              {['blue', 'teal', 'emerald', 'amber', 'rose', 'violet'].map((col) => (
                <button
                  key={col}
                  type="button"
                  onClick={() => setColor(col)}
                  className={`h-6 w-6 rounded-full border-2 cursor-pointer transition-transform ${
                    color === col ? 'scale-110 border-white font-bold' : 'border-transparent opacity-70'
                  }`}
                  style={{
                    backgroundColor: 
                      col === 'blue' ? '#3b82f6' :
                      col === 'teal' ? '#14b8a6' :
                      col === 'emerald' ? '#10b981' :
                      col === 'amber' ? '#f59e0b' :
                      col === 'rose' ? '#f43f5e' :
                      '#8b5cf6'
                  }}
                />
              ))}
            </div>
          </div>

          <div className="flex gap-4 mt-2">
            <button
              type="submit"
              id="ifs-part-submit-btn"
              className="flex-1 bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-500 hover:to-indigo-600 font-sans font-medium text-sm text-white py-2.5 rounded-xl cursor-pointer"
            >
              Commit Part to Psyche System
            </button>
            <button
              type="button"
              id="ifs-part-cancel-btn"
              onClick={() => setShowAddForm(false)}
              className="bg-slate-950/80 border border-slate-800 hover:bg-slate-850 px-4 py-2 text-slate-400 text-sm font-sans font-medium rounded-xl hover:text-slate-200 cursor-pointer"
            >
              Cancel
            </button>
          </div>
        </form>
      ) : (
        /* Categorized columns corresponding to internal systems of protectors & exiles */
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Managers column */}
          <div className="flex flex-col gap-4">
            <div className="flex items-center gap-2 border-b border-blue-900/40 pb-2.5">
              <Shield className="h-4.5 w-4.5 text-blue-400" />
              <h4 className="font-sans font-semibold text-sm text-blue-200">MANAGERS (PROACTIVE)</h4>
              <span className="text-[10px] font-mono bg-blue-950/80 border border-blue-900/60 text-blue-300 px-2 py-0.5 rounded-full ml-auto">
                {parts.filter(p => p.type === 'manager').length}
              </span>
            </div>
            
            {parts.filter(p => p.type === 'manager').length === 0 ? (
              <p className="text-xs text-slate-500 italic py-6 text-center border border-dashed border-slate-800/80 rounded-xl font-sans">
                No active Managers logged yet. Add parts above.
              </p>
            ) : (
              parts.filter(p => p.type === 'manager').map((part) => (
                <PartCard key={part.id} part={part} getStyles={getPartTypeStyles} onDelete={onDeletePart} />
              ))
            )}
          </div>

          {/* Firefighters Column */}
          <div className="flex flex-col gap-4">
            <div className="flex items-center gap-2 border-b border-rose-900/40 pb-2.5">
              <Flame className="h-4.5 w-4.5 text-rose-400" />
              <h4 className="font-sans font-semibold text-sm text-rose-200">FIREFIGHTERS (REACTIVE)</h4>
              <span className="text-[10px] font-mono bg-rose-950/80 border border-rose-900/60 text-rose-300 px-2 py-0.5 rounded-full ml-auto">
                {parts.filter(p => p.type === 'firefighter').length}
              </span>
            </div>
            
            {parts.filter(p => p.type === 'firefighter').length === 0 ? (
              <p className="text-xs text-slate-500 italic py-6 text-center border border-dashed border-slate-800/80 rounded-xl font-sans">
                No active Firefighters cataloged. Add parts above.
              </p>
            ) : (
              parts.filter(p => p.type === 'firefighter').map((part) => (
                <PartCard key={part.id} part={part} getStyles={getPartTypeStyles} onDelete={onDeletePart} />
              ))
            )}
          </div>

          {/* Exiles Column */}
          <div className="flex flex-col gap-4">
            <div className="flex items-center gap-2 border-b border-violet-900/40 pb-2.5">
              <User className="h-4.5 w-4.5 text-violet-400" />
              <h4 className="font-sans font-semibold text-sm text-violet-200">EXILES (WOUNDED)</h4>
              <span className="text-[10px] font-mono bg-violet-950/80 border border-violet-900/60 text-violet-300 px-2 py-0.5 rounded-full ml-auto">
                {parts.filter(p => p.type === 'exile').length}
              </span>
            </div>
            
            {parts.filter(p => p.type === 'exile').length === 0 ? (
              <p className="text-xs text-slate-500 italic py-6 text-center border border-dashed border-slate-800/80 rounded-xl font-sans">
                No exiles fully unburdened or currently mapped. Add parts above.
              </p>
            ) : (
              parts.filter(p => p.type === 'exile').map((part) => (
                <PartCard key={part.id} part={part} getStyles={getPartTypeStyles} onDelete={onDeletePart} />
              ))
            )}
          </div>

        </div>
      )}
    </div>
  );
}

// Sub Card to reduce file bloat
interface PartCardProps {
  key?: string;
  part: IFSPart;
  getStyles: (type: PartType) => any;
  onDelete: (id: string) => void;
}

function PartCard({ part, getStyles, onDelete }: PartCardProps) {
  const [expanded, setExpanded] = useState(false);
  const info = getStyles(part.type);

  const getBorderColorClass = (colorName: string) => {
    switch (colorName) {
      case 'amber': return 'border-amber-900/30 hover:border-amber-800/60 focus:border-amber-500';
      case 'rose': return 'border-rose-900/30 hover:border-rose-800/60 focus:border-rose-500';
      case 'emerald': return 'border-emerald-900/30 hover:border-emerald-800/60 focus:border-emerald-500';
      case 'teal': return 'border-teal-900/30 hover:border-teal-800/60 focus:border-teal-500';
      case 'violet': return 'border-violet-900/30 hover:border-violet-800/60 focus:border-violet-500';
      default: return 'border-blue-900/30 hover:border-blue-800/60 focus:border-blue-500';
    }
  };

  const getSomaticBulletBg = (colorName: string) => {
    switch (colorName) {
      case 'amber': return 'bg-amber-950/70 border-amber-900/40 text-amber-300';
      case 'rose': return 'bg-rose-950/70 border-rose-900/40 text-rose-300';
      case 'emerald': return 'bg-emerald-950/70 border-emerald-900/40 text-emerald-300';
      case 'teal': return 'bg-teal-950/70 border-teal-900/40 text-teal-300';
      case 'violet': return 'bg-violet-950/70 border-violet-900/40 text-violet-300';
      default: return 'bg-blue-950/70 border-blue-900/40 text-blue-300';
    }
  };

  return (
    <div
      onClick={() => setExpanded(!expanded)}
      className={`group bg-slate-900/70 border rounded-xl overflow-hidden transition-all duration-300 cursor-pointer shadow-sm hover:shadow-indigo-950/10 flex flex-col p-4.5 ${getBorderColorClass(part.color)}`}
    >
      <div className="flex items-start justify-between gap-3">
        <h5 className="font-sans font-medium text-sm text-slate-200 group-hover:text-indigo-300 transition-colors leading-snug">
          {part.name}
        </h5>
        
        <button
          onClick={(e) => {
            e.stopPropagation();
            onDelete(part.id);
          }}
          className="p-1 cursor-pointer text-slate-600 hover:text-red-400 transition-colors bg-slate-950/20 hover:bg-slate-950 rounded-md"
          title="Archive Part"
        >
          <Trash2 className="h-3.5 w-3.5" />
        </button>
      </div>

      <p className="text-xs text-slate-400/90 leading-relaxed font-sans mt-2 line-clamp-3">
        {part.role}
      </p>

      {/* Somatic Tags Row */}
      {part.associatedSensations?.length > 0 && (
        <div className="flex flex-wrap gap-1 mt-3.5">
          {part.associatedSensations.map((sens, idx) => (
            <span key={idx} className={`text-[9px] font-mono leading-none px-2 py-1 rounded-full border ${getSomaticBulletBg(part.color)}`}>
              {sens}
            </span>
          ))}
        </div>
      )}

      {/* Expanded view */}
      {expanded && (
        <div className="border-t border-slate-800/80 pt-3.5 mt-4 flex flex-col gap-3.5 animate-fade-in">
          <div className="flex flex-col gap-1 text-[11px]">
            <span className="font-mono text-slate-500 uppercase tracking-wider">POSITIVE CORE INTENSITY / PLAN</span>
            <p className="font-sans text-slate-300 leading-relaxed bg-slate-950/30 p-2.5 rounded border border-slate-850">
              {part.role}
            </p>
          </div>

          <div className="flex flex-col gap-1 text-[11px]">
            <span className="font-mono text-rose-400 uppercase tracking-wider">PROTECTIVE SYSTEM FEAR</span>
            <p className="font-sans text-slate-300 leading-relaxed bg-rose-950/10 p-2.5 rounded border border-rose-950/35">
              {part.fear || 'Unspecified fear.'}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
