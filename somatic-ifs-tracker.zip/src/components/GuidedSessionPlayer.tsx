import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, Pause, RotateCcw, Volume2, Sparkles, Compass, Wind, Heart, ChevronRight } from 'lucide-react';
import { GuidedSession } from '../types';

const SESSIONS: GuidedSession[] = [
  {
    id: "g1",
    title: "Somatic Tracking & Describing",
    description: "Learn to sit with neutral curiosity. Track a physical sensation outline, observing its border, color, density, and flow without wanting it to change.",
    durationSeconds: 180,
    category: "somatics",
    steps: [
      "Let's settle into an upright, supportive posture. Feel your thighs and sitbones connected to your chair.",
      "Bring your awareness into your physical body. Locate any somatic sensation that holds tightness, tension, or density.",
      "Instead of wishing it were gone, look at it with the curiosity of a scientist. What are its exact boundaries? Is it sharp or fuzzy?",
      "Ask: Is it heavy or light? Liquid or solid? Hot or cool? Give it precise descriptors in your head.",
      "Notice if any judgment arises towards the feeling ('I hate this tightness'). Wave a gentle greeting at the judgment, and return simply to tracking the physical raw data.",
      "Breath can flow normally. Imagine breathing directly into the perimeter of this sensation, creating a tiny bit of space around it.",
      "Notice if the sensation has shifted, moved, or changed shape. Whatever it does is completely welcome."
    ]
  },
  {
    id: "g2",
    title: "Grounding and Resourcing (Pendulation)",
    description: "Oscillate attention between an area of tightness, and a pleasant or neutral 'resource area' in your body or room to expand safety thresholds.",
    durationSeconds: 240,
    category: "grounding",
    steps: [
      "Start by scanning your body for a 'resource place.' This is any spot (your feet, your hands, your ears) that feels neutral, pleasant, or steady.",
      "Rest your focus on this resource place for 15 seconds. Relish the neutral, safe feeling here.",
      "Now, shift your focus gently to the area of discomfort or somatic tightness. Let your eyes observe it for just 5 seconds.",
      "At the first sign of distress, swing your focus straight back to your safe resource place. Let your nervous system sink into safety once again.",
      "Take 3 easy, slow breaths while resting in your safe resource. Feel the expansion on the inhaled air.",
      "Slowly oscillate again: touch the tight area with 5 seconds of soft curiosity, then slide back to the comfortable resource.",
      "This process of pendulation teaches your brain that discomfort is temporary and can be held inside a larger field of safety."
    ]
  },
  {
    id: "g3",
    title: "Nervous System Regulation (Box Breathing)",
    description: "Use a structured 4-4-4-4 breathing cycle to down-regulate high anxiety states and help overactive protective parts step back.",
    durationSeconds: 120,
    category: "resourcing",
    steps: [
      "Prepare to synchronize your breath. Let out all of your air.",
      "Inhale deeply through your nose for 4 seconds, feeling your stomach expand.",
      "Hold that breath gently at the peak of your lungs for 4 seconds.",
      "Exhale slowly out your mouth for 4 seconds, like blowing through a straw.",
      "Hold your lungs empty for 4 seconds before the next cycle.",
      "Let the animated guide on the screen represent your physical breath. Keep cycling.",
      "When the nervous system feels regulated, protective parts can relax knowing that you are safe in this present moment."
    ]
  },
  {
    id: "g4",
    title: "Connecting with a Protective Part",
    description: "An IFS guided visualization to meet, validate, and appreciate a protective strategy (like an inner critic, worry, or drive).",
    durationSeconds: 300,
    category: "parts-dialogue",
    steps: [
      "Scan inside and name the active protector part of you (e.g. 'the driver', 'the anxious one'). Locate its physical footprint in your body.",
      "Check: How do you feel towards this part? If you feel annoyed or scared of it, ask those critical parts to step aside for a moment so we can learn.",
      "With pure curiosity, ask the part: 'What is your job in my life? What are you trying to do for me?' Wait and listen to what it shows or says.",
      "Ask it: 'What is your worst fear? What are you afraid would happen to me if you did not do this job?' Allow its fear to be heard.",
      "Fully acknowledge its answers. Say to it: 'I see how hard you work. Thank you for trying to keep me safe for so long.' Feel any softening in your body.",
      "Let the part know you are here. Sit together in presence, in quiet 'Self-energy' connection."
    ]
  }
];

export default function GuidedSessionPlayer() {
  const [selectedSession, setSelectedSession] = useState<GuidedSession>(SESSIONS[0]);
  const [isActive, setIsActive] = useState(false);
  const [currentStepIdx, setCurrentStepIdx] = useState(0);
  const [timeLeft, setTimeLeft] = useState(SESSIONS[0].durationSeconds);
  const [breathPhase, setBreathPhase] = useState<'inhale' | 'hold-full' | 'exhale' | 'hold-empty'>('inhale');
  const [breathValue, setBreathValue] = useState(0); // 0 to 100 for breathing radial loop
  
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const breathTimerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    setTimeLeft(selectedSession.durationSeconds);
    setCurrentStepIdx(0);
    setIsActive(false);
  }, [selectedSession]);

  // Main countdown timer
  useEffect(() => {
    if (isActive && timeLeft > 0) {
      timerRef.current = setTimeout(() => {
        setTimeLeft(prev => prev - 1);
        
        // Auto progress steps based on duration segments
        const timeSpent = selectedSession.durationSeconds - timeLeft;
        const totalSteps = selectedSession.steps.length;
        const secondsPerStep = selectedSession.durationSeconds / totalSteps;
        const nextStep = Math.min(Math.floor(timeSpent / secondsPerStep), totalSteps - 1);
        
        if (nextStep !== currentStepIdx) {
          setCurrentStepIdx(nextStep);
        }
      }, 1000);
    } else if (timeLeft === 0 && isActive) {
      setIsActive(false);
    }

    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [isActive, timeLeft, selectedSession]);

  // Breathing lung guide loop (4s segments for Box Breathing)
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isActive) {
      let counter = 0;
      interval = setInterval(() => {
        counter = (counter + 1) % 16;
        if (counter < 4) {
          setBreathPhase('inhale');
          setBreathValue((counter / 4) * 100);
        } else if (counter >= 4 && counter < 8) {
          setBreathPhase('hold-full');
          setBreathValue(100);
        } else if (counter >= 8 && counter < 12) {
          setBreathPhase('exhale');
          setBreathValue(100 - (((counter - 8) / 4) * 100));
        } else {
          setBreathPhase('hold-empty');
          setBreathValue(0);
        }
      }, 1000);
    }

    return () => clearInterval(interval);
  }, [isActive]);

  const toggleActive = () => {
    setIsActive(!isActive);
  };

  const resetSession = () => {
    setIsActive(false);
    setTimeLeft(selectedSession.durationSeconds);
    setCurrentStepIdx(0);
    setBreathPhase('inhale');
    setBreathValue(0);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const getBreathLabel = () => {
    switch (breathPhase) {
      case 'inhale': return 'Inhale';
      case 'hold-full': return 'Hold / Stabilize';
      case 'exhale': return 'Slow Exhale';
      case 'hold-empty': return 'Quiet Pause';
    }
  };

  return (
    <div className="bg-slate-900/40 border border-slate-800 p-6 rounded-2xl backdrop-blur-md shadow-lg flex flex-col h-full">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Compass className="h-5 w-5 text-indigo-400" />
          <h3 className="font-sans font-medium text-lg text-slate-100">Somatic & IFS Exercises</h3>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-mono text-slate-500">EXPERIENCE CENTRE</span>
        </div>
      </div>

      {/* Selector tab */}
      <div className="flex flex-col gap-1.5 mb-6">
        <label className="text-xs font-mono text-slate-400">SELECT INNER PRACTICE</label>
        <select
          id="guided-practice-select"
          value={selectedSession.id}
          onChange={(e) => {
            const found = SESSIONS.find(s => s.id === e.target.value);
            if (found) setSelectedSession(found);
          }}
          className="w-full bg-slate-950/70 border border-slate-800 text-slate-200 text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 font-sans"
        >
          {SESSIONS.map((session) => (
            <option key={session.id} value={session.id}>
              {session.title} ({session.durationSeconds / 60}m)
            </option>
          ))}
        </select>
        <p className="text-xs text-slate-400/90 leading-relaxed italic border-l-2 border-indigo-900/60 pl-3 py-1 mt-1 font-sans">
          {selectedSession.description}
        </p>
      </div>

      {/* Beautiful Dynamic Lung/Somatic breathing visualizer */}
      <div className="flex-1 flex flex-col md:flex-row items-center gap-6 py-4 justify-center">
        
        {/* Breathing balloon animation area */}
        <div className="relative w-44 h-44 flex items-center justify-center shrink-0">
          
          {/* External ambient pulse ring */}
          <div className="absolute inset-0 rounded-full border border-slate-800/80 scale-100 opacity-20 bg-slate-800/10 pointer-events-none"></div>
          
          {/* Animated breath scale core from motion */}
          <motion.div
            id="breathing-circle-balloon"
            className={`absolute rounded-full flex flex-col items-center justify-center ${
              breathPhase === 'inhale' || breathPhase === 'hold-full' 
                ? 'bg-indigo-500/20 shadow-[0_0_35px_rgba(99,102,241,0.25)]' 
                : 'bg-teal-500/20 shadow-[0_0_35px_rgba(20,184,166,0.25)]'
            }`}
            animate={{
              scale: isActive 
                ? breathPhase === 'inhale' ? [1.1, 1.45] 
                : breathPhase === 'hold-full' ? 1.45
                : breathPhase === 'exhale' ? [1.45, 1.05]
                : 1.05
                : 1.1,
            }}
            transition={{
              duration: breathPhase === 'inhale' ? 4 : breathPhase === 'exhale' ? 4 : 4,
              ease: "easeInOut",
            }}
            style={{
              width: '110px',
              height: '110px',
            }}
          >
            <div className={`p-2.5 rounded-full ${breathPhase === 'inhale' || breathPhase === 'hold-full' ? 'bg-indigo-500/10 text-indigo-300' : 'bg-teal-500/10 text-teal-300'}`}>
              {selectedSession.category === 'somatics' ? <Compass className="h-5 w-5 animate-spin-slow" /> :
               selectedSession.category === 'grounding' ? <Heart className="h-5 w-5" /> : <Wind className="h-5 w-5" />}
            </div>
          </motion.div>

          {/* Core Labels */}
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none mt-16 text-center select-none">
            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400">
              {isActive ? getBreathLabel() : 'Ready'}
            </span>
          </div>
        </div>

        {/* Informational prompt steps cards */}
        <div className="flex-1 min-w-[200px] flex flex-col justify-center h-full">
          <div className="text-[9px] font-mono tracking-widest text-indigo-400 uppercase mb-1">
            STEP {currentStepIdx + 1} OF {selectedSession.steps.length}
          </div>
          
          <div className="min-h-[140px] flex flex-col justify-between bg-slate-950/40 rounded-xl p-4.5 border border-slate-800/60 relative overflow-hidden">
            
            {/* Ambient indicator glow */}
            <div className="absolute top-0 left-0 w-1.5 h-full bg-gradient-to-b from-indigo-500 to-teal-500"></div>

            <AnimatePresence mode="wait">
              <motion.p
                key={currentStepIdx}
                initial={{ opacity: 0, x: 15 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -15 }}
                transition={{ duration: 0.35 }}
                className="text-slate-100 font-sans text-sm leading-relaxed pl-2 font-light"
              >
                {selectedSession.steps[currentStepIdx]}
              </motion.p>
            </AnimatePresence>

            <div className="flex items-center justify-between mt-4">
              <div className="flex items-center gap-1.5 pl-2">
                <span className="text-xs font-mono font-medium text-slate-300">{formatTime(timeLeft)}</span>
                <span className="text-[10px] font-mono text-slate-500">remaining</span>
              </div>
              
              {/* Force Next Step manual overrider */}
              {isActive && (
                <button
                  id="guide-next-step-button"
                  onClick={() => {
                    setCurrentStepIdx(prev => (prev + 1) % selectedSession.steps.length);
                  }}
                  className="flex items-center gap-1 text-[11px] font-medium text-indigo-400 hover:text-indigo-300 transition-colors font-sans pl-3 py-1"
                >
                  Skip Step <ChevronRight className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Control Buttons row */}
      <div className="flex items-center gap-4 border-t border-slate-800/80 pt-4 mt-auto">
        <button
          id="btn-somatic-practice-play"
          onClick={toggleActive}
          className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-xl font-medium font-sans text-sm transition-all duration-300 cursor-pointer shadow-md ${
            isActive 
              ? 'bg-slate-800 hover:bg-slate-700 text-slate-100' 
              : 'bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-500 hover:to-indigo-600 text-white'
          }`}
        >
          {isActive ? (
            <>
              <Pause id="icon-pause-practice" className="h-4 w-4" /> Pause Practice
            </>
          ) : (
            <>
              <Play id="icon-play-practice" className="h-4 w-4" /> Start Healing Guide
            </>
          )}
        </button>

        <button
          id="btn-somatic-practice-reset"
          onClick={resetSession}
          title="Reset session"
          className="p-3 bg-slate-950/80 border border-slate-800 hover:bg-slate-800/60 transition-colors rounded-xl text-slate-400 hover:text-slate-200 cursor-pointer"
        >
          <RotateCcw className="h-4.5 w-4.5" />
        </button>
      </div>
    </div>
  );
}
